<?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title> Dashboard</title>
<style>
    .height
    {
        height: 115px;
    }
</style>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
            <div class="row">
           
    
                <div class="col-xl-3 col-lg-6">
                  <div class="card">
                    <a href="#" class="text-decoration-none height">
                      <div class="p-t-20 d-flex justify-content-between">
                        <div class="col">
                          <h6 class="mb-0 font-15 col-black">Game</h6>
                          <span class="font-weight-bold mb-0 font-20 col-green"></span>
                        </div>
                        <i class="	fas fa-gamepad card-icon col-green font-30 p-r-10"> <?php echo e(count($game)); ?></i>
                      </div>
                    </a>
                  <div>
                </div>
              </div>
        </section>
      </div>
<?php echo $__env->make('admin.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sattaki1/satta-king-786.org/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>