<title>Satta-king-786.org - Provide Satta king game online live results upto date And Satta king fix single jodi chart</title>
<meta name="description" content="Black satta, Satta king online, Disawar satta, Satta king 786, Satta bajar, Satta record chart, Disawar satta, Satta king 2023, Ghaziabad satta, Satta king result, Satta king game, Gali satta, Delhi satta king  " />
<meta name="keywords" content="Satta king, Satta king fast, Sattaking, Satta chart, Satta bajar, Satta number, Satta king 786,Desawar satta king, Satta king result, Satta result, Gali satta, Satta king live result " />
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
    About Us

      </h1>

    </div>
  </section>
  
 <!-- Admin Game Start -->
  <section>
    <div class="datetime_section">
      <div id="datetime" class="datetime_box">

      </div>
    </div>

    <div class="text_section">

  <?php echo $__env->make('frontend.gamecode.gamename', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

  </section>
  
  <!-- Admin Game End -->
  
  


  <!-- result section -->
  <section>

   <div class="result_box">
    <?php echo $__env->make('frontend.gamecode.result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    </div>
  </section>

 <!-- result section end --> 
 
  





<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sattaki1/satta-king-786.org/resources/views/frontend/aboutus.blade.php ENDPATH**/ ?>