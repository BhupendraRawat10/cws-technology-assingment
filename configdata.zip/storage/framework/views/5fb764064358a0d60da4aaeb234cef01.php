<section>
  <div class="footer-section">
    <div class="footer_section">

      <a  href="<?php echo e(route('index_login')); ?>" class="footer_button">
        <button type="button" class="button_format_footer">Home</button>
    </a>
        
        <a href="<?php echo e(route('game_login')); ?>" class="footer_button">
      <button type="button"  class="button_format_footer">Login</button>
      </a>
      
      <a href="<?php echo e(url('contact-us')); ?>" class="footer_button">
      <button type="button" class="button_format_footer">Contact</button>
      </a>
        <a href="<?php echo e(url('about-us')); ?>" class="footer_button">
      <button type="button" class="button_format_footer">About</button>
      </a>
         <a href="<?php echo e(url('disclaimer')); ?>" class="footer_button">
      <button type="button" class="button_format_footer">Disclaimer</button>
      </a>
      
      <a href="<?php echo e(route('game_register')); ?>" class="footer_button">
      <button type="button" class="button_format_footer">Registration</button>
      </a>
      
    </div>

</section>

<section>
  <div class="contact-part">
    <p class="footer-text"> © All Right Reserved - 2023</p>

    <p class="footer-text"> CONTACT (ADMIN)</p>

    <p class="footer-text"> 085XXXXXX42</p>
  </div>
</section>

  <!-- footer section -->









</body>

</html> <?php /**PATH C:\xampp\htdocs\wellknown\resources\views/frontend/include/footer.blade.php ENDPATH**/ ?>