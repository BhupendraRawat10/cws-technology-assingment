<title>Satta bazar | Satta king chart | Gali satta | Satta king disawar | Satta record chart </title>
<meta name="description" content="Satta chart, Satta king delhi, Black satta, Satta king chart, Gali satta, Satta king online, Disawar satta, Ghaziabad satta, Satta king, Satta bajar, Disawar satta chart, Satta record satta, Gali satta king " />
<meta name="keywords" content="Satta king chart, Delhi satta, Satta record chart, Satta number, Satta king gali disawar, Satta bazar, Gali satta, Disawar satta, Ghaziabad satta, Gali disawar chart " />
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/newstyle.css')); ?>">
<?php
    
$current_year = date('Y');
?>
  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
    Satta King Chart
      </h1>

    </div>
  </section>
  <div class="text_slide"  >
    <marquee>
      <h5 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
      Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
      Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king 2024, 786 satta king, Satta king game</h5>
    </marquee>
  </div>
    <div class="text_slide">
  
        <div class="text-center mt-2">
       <h2  style="font-size:2.5rem">   
        Satta Record Chart for <?php echo e($current_year); ?> of Gali, Disawar, Faridabad and Ghaziabad Satta
       </h2>
      <p class="text-custom" style="color:blue">satta-king-786.org is the official website for showing Satta Record Charts for 2024 verified from satta company office, here you can find the record charts for Gali Satta record chart 2024, Disawar Satta record chart 2024, Faridabad Satta record chart 2024 and Ghaziabad Satta record chart 2024</p>
        <h4 class="text-custom-data">
            Official Satta Record Chart for <?php echo e($current_year); ?> of Gali and Satta King 786 Charts of <?php echo e($current_year); ?> for Disawar, Faridabad, Ghaziabad and Gali Direct from Company Office  
      </h4>     

  
  </div>
    </div>





    <?php
        $currentYear = now()->year;
        $groupedData = collect($uniqueDates)->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date)->format('F Y');
        });

        $currentMonth = null;
    ?>

    <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $dates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $firstDate = \Carbon\Carbon::parse($dates->first());
            $year = $firstDate->year;
        ?>

        <?php if($year == $currentYear): ?>
       

     
            <table id="customers">
              
                    <tr id="newformate">
                        <th >
                            Date
                        </th>
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th >
                                <?php echo e($result); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
               
                <tbody>
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $dateCarbon = \Carbon\Carbon::parse($date);
                        ?>

                        <tr                     
                    >
                            <td >
                                <?php echo e($dateCarbon->format('d-M-Y')); ?>

                            </td>

                            <?php
                            $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                ->where('date', $date)
                                ->get()
                                ->keyBy('game_fk_id');
                            ?>
                        
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $result = $results->get($gameId);
                            ?>
                            <td class="">
                                <?php if($result): ?>
                                    <?php echo e($result->result); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            
                        
                        
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php
                        $currentMonth = $month;
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!is_null($currentMonth)): ?>
                </tbody>
            </table>
    
        <?php endif; ?>
    




 <!-- record chart -->
 <section>

  
  
    <?php if(count($gameresultsdata) > 0): ?>
      <?php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      ?>

      <?php $__currentLoopData = $sortedYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($loop->iteration >= count($sortedYears) - 2): ?>
              <?php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              ?>

              <?php if($uniqueGames->isNotEmpty()): ?>

                  <?php if($loop->first): ?>
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  <?php endif; ?>

                  <?php $__currentLoopData = $uniqueGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      $currentDate = new DateTime($result['date']);
                      $gameId = $result['game']['id'] ?? null;
                      ?>

                      <?php if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74])): ?>
                      <div class="newchart text-black">
                        <p class="newchart_content"> <a style="text-decoration: none; color: black;" href="<?php echo e(route('new_page_year',['year'=> $year])); ?>">SATTA KING RECORD CHART  <?php echo e($year); ?></a></p>
                    </div>
                      <?php endif; ?>

                      

                      <?php
                          $previousYear = $currentDate->format('Y');
                      ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
      <p class="text-black">No game results available for the current year.</p>
  <?php endif; ?>




  </section>




  <!-- form section -->

<section class="bgwhite p4 m4_universal">
    <div>
    <p>
        


    </p>
    </div>
</section>






<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/satta-king-game-record-chart.blade.php ENDPATH**/ ?>