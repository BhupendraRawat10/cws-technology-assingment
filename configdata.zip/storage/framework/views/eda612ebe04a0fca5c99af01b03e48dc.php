<html>

<head>
  <link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/css/newstyle.css')); ?>">
                  
  <link href="<?php echo e(asset('public/image/786.png')); ?>" rel="shortcut icon" type="image/icon" />
  <title><?php echo e($title); ?></title>
  <meta content=<?php echo e($description); ?>>
  <meta content=<?php echo e($keywords); ?>>
</head>

<body>
  <!-- this for header section -->
  
  <?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
        Satta King Registration

      </h1>

    </div>
  </section>


  <!-- form section -->

<section>
    <div class="login-form">
        <p class="login-text">User Registration</p>
    

    
<form>
  <div class="grid-container">
    <div class="form-section">
        <div class="input_field">
            <div class="label-name">Login Name</div>
            <input type="text"  name="name" class="field" placeholder="Enter Username">
        </div>
    </div>
    <div class="form-section">
        <div class="input_field">
            <div class="label-name">Password</div>
            <input type="number"  name="password" class="field" placeholder="Enter Password">
        </div>
    </div>
    <div class="form-section">
        <div class="input_field">
            <div class="label-name">Verify Password</div>
            <input type="number"  name="verify password" class="field" placeholder="Enter Verify Password">
        </div>
    </div>
    <div class="form-section">
        <div class="input_field">
            <div class="label-name">Security Question</div>
            <input type="text"  name="question" class="field" placeholder="Enter Security Question">
        </div>
    </div>
    <div class="form-section">
        <div class="input_field">
            <div class="label-name">Security Answer</div>
            <input type="text"  name="answer" class="field" placeholder="Enter Security Answer">
        </div>
    </div>
  </div>
       
     
              
       
       
          <div class="form-login">
            <button type="button" class="login-button">Register</button>
          </div>

   
    
  </form>
</div>
</section>


 <!-- Admin Game Start -->
  <section>
    <div class="datetime_section">
      <div id="datetime" class="datetime_box">

      </div>
    </div>

    <div class="text_section">

  <?php echo $__env->make('frontend.gamecode.gamename', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

  </section>
  
  <!-- Admin Game End -->
  
  


  <!-- result section -->
  <section>

   <div class="result_box">
    <?php echo $__env->make('frontend.gamecode.result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    </div>
  </section>

 <!-- result section end -->



  <!-- footer section -->


  <style>
    .button_format_footer {
      background-color: #ffe87c;
      font-size: 20px;
      border: none;
      color: #ff0000;
      font-weight: 700;
      cursor: pointer;
  }
  @media only screen and (max-width: 480px) {
   
   .footer_section {
       width: 50%;
       display: flex;
       justify-content: center;
       gap: 5px;
       flex-wrap: wrap;
   }
  
   }
  </style>
  <section>
    <div class="footer-section">
      <div class="footer_section">
  
        <a  href="<?php echo e(route('index_login')); ?>" class="footer_button">
          <button type="button" class="button_format_footer">Home</button>
      </a>
          
          <a href="<?php echo e(route('game_login')); ?>" class="footer_button">
        <button type="button"  class="button_format_footer">Login</button>
        </a>
        
        <a href="<?php echo e(url('contact-us')); ?>" class="footer_button">
        <button type="button" class="button_format_footer">Contact</button>
        </a>
      
        <a href="<?php echo e(route('game_register')); ?>" class="footer_button">
        <button type="button" class="button_format_footer">Registration</button>
        </a>
        
      </div>
  
  </section>
  
  <section>
    <div class="contact-part">
      <p class="footer-text"> © All Right Reserved - 2023</p>
  
      <p class="footer-text"> CONTACT (ADMIN)</p>
  
      <p class="footer-text"> 085XXXXXX42</p>
    </div>
  </section>
  


</body>

</html><?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/register.blade.php ENDPATH**/ ?>