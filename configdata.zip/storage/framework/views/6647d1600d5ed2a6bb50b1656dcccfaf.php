<?php
$today = now()->toDateString(); 
$gamesmyvariable = \App\Models\Game::whereIn('id', [2, 64, 68])
    ->where('Is_admin_game', 1)
    ->with(['gameResults' => function ($query) use ($today) {
        $query->whereDate('date', $today)->latest('date');
    }])
    ->get();
?>

<?php $__currentLoopData = $gamesmyvariable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1 class="result_parts_first"><?php echo e($game->name); ?></h1>

    <?php $__empty_1 = true; $__currentLoopData = $game->gameResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="text_first">
            <pre class="text_first"><?php echo e($result->result); ?></pre>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text_first">wait</p>
    <?php endif; ?>

    <?php if($game->id === 74): ?>
        <p class="text-2xl text-yellow">Hello</p>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php
  use Carbon\Carbon;
  $currentTime = Carbon::now();
  $targetTime = Carbon::createFromTime(10, 0, 0); // 10:00:00
  $isBeforeTargetTime = $currentTime->lessThan($targetTime);

  $yesterday = now()->subDay()->toDateString(); // Get yesterday's date

$gamesmyvariabledata =  \App\Models\Game::whereIn('id', [74]) 
->where('Is_admin_game', 1)
    ->with(['gameResults' => function ($query) use ( $yesterday) {
        $query->whereDate('date', $yesterday)
            ->latest('date');
    }])
    ->get();
?>
<?php $__currentLoopData = $gamesmyvariabledata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h2 class="result_parts_first"><?php echo e($game->name); ?></h2>
  
  <?php if($isBeforeTargetTime): ?>
       <?php if($game->gameResults && $game->gameResults->isNotEmpty()): ?>
          <?php $__currentLoopData = $game->gameResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="pt-2 text_first text-3xl">
                  <pre class="text-2xl text_first"><?php echo e($result->result); ?></pre>
              </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
          <p class="text_first">wait</p>
      <?php endif; ?>
  <?php else: ?>

      <p class="text_first">wait</p>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php /**PATH /home/sattaki1/satta-king-786.org/resources/views/frontend/gamecode/gamename.blade.php ENDPATH**/ ?>