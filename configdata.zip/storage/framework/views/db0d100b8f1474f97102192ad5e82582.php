<?php
$current_time = now()->toDateString();
$previous_day = now()->subDay()->toDateString();

$games = \App\Models\Game::get();
?>

<?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $game_results = \App\Models\GameResult::where('game_fk_id', $game->id)
        ->whereIn('date', [$previous_day, $current_time])
        ->orderBy('date', 'asc') 
        ->get();

    $count = $game_results->count();
    ?>

    <div class="result_box_description">
        <h5 class="result_text"><?php echo e($game->name); ?></h5>
        <h3><?php echo e(\Carbon\Carbon::parse($game->open_time)->format('g:i A')); ?></h3>

        <?php if($count > 0): ?>
            <div class="box_text">
                <?php $__currentLoopData = $game_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($result): ?>
                <?php if($loop->iteration == 1): ?>
                    <h6 class="result_number_old">(<?php echo e($result->result ?? '()'); ?>) <br> <span class="old">old</span></h6>
                <?php else: ?>
                <h6 class="result_number">[<?php echo e($result->result ?? '()'); ?>] <br> <span class="new">new</span></h6>
                <?php endif; ?>
                    <div class="image_gif_parts">
                        <?php if($loop->iteration == 1): ?>
                            <img src="public/image/new.gif" class="image_gif" />
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <h6 class="result_number">[]</h6>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(count($game_results) == 1): ?>
            <h6 class="result_number">[]</h6>
      
            <?php endif; ?>
            
    
          
          
                
            </div>
        <?php else: ?>
        <div class="box_text">
        <h6 class="result_number">()</h6>
        
        <div class="image_gif_parts">
          <img src="public/image/new.gif" class="image_gif" />
        </div>
        
        <h6 class="result_number">()</h6>
        </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\wellknown\resources\views/frontend/gamecode/result.blade.php ENDPATH**/ ?>