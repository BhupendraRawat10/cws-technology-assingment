</div>
<!-- General JS Scripts -->
<script src="<?php echo e(asset('public/assets/js/app.min.js')); ?>"></script>
<!-- JS Libraies -->
<!-- Page Specific JS File -->
<!-- Template JS File -->
<script src="<?php echo e(asset('public/assets/js/scripts.js')); ?>"></script>
<!-- Custom JS File -->
<script src="<?php echo e(asset('public/assets/js/custom.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/bundles/izitoast/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/page/toastr.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\game\resources\views/include/footer.blade.php ENDPATH**/ ?>