<html>
<head>
    
    <title><?php echo e($title); ?></title>
    <meta name="description" content="<?php echo e($description); ?>" />
    <meta name="keywords" content="<?php echo e($keywords); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="og:image" content="<?php echo e(asset('public/image/786.png')); ?>" />
  <meta property="og:title" content="Satta King Official Website" />
  <meta property="og:description" content="We Are Satta King 786" />
  <meta property="og:locale" content="en_IN" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="Satta King " />
  <meta property="og:url" content="https://satta-king-786.org/" />
  <meta name="robots" content="index, follow">
  <link href="<?php echo e(asset('public/image/786.png')); ?>" rel="shortcut icon" type="image/icon" />
    <link rel="canonical" href="https://satta-king-786.org" />
    
  
  
  <link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>">
  <style>
.header_button {
    width: 102%;
    /* display: flex; */
    gap: 5px;
}

    .Satta_king_content{
      font-size: 45px;
    }
    .call-button,.whatsapp-button{
      font-size: 20px;
    }
    .main_section {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
    }

    .menu_button {
      margin: 5px;
    }

    .btn_format {
      padding: 10px 20px;
      font-size: 16px;
    }

    /* Adjust button size for smaller screens */
    @media screen and (max-width: 600px) {
      .btn_format {
        padding: 1px !important;
        font-size: 14px;
      }
      .menu_button{
          margin:0;
          border:0px;
          box-shadow: none;
      }
    }
  </style>
  <script>
    function displayDateTime() {
      var now = new Date();
      var dateString = now.toDateString(); // Get the date as a string
      var hours = now.getHours() % 12 || 12;
      var timeString = hours + ":" + now.getMinutes() + ":" + now.getSeconds() + " " + (now.getHours() >= 12 ? "PM" : "AM");
      // Display the date and time in a specific element
      document.getElementById("datetime").innerHTML = " " + dateString + " " + timeString;
    }

    // Call the function when the page is loaded
    window.onload = displayDateTime;
    setInterval(() => {
      displayDateTime();
    }, 1000);
  </script>
  <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-8QMG5T77T6"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-8QMG5T77T6');
</script>
</head>
<body>
  <!-- this for header section -->
  <section>
    <div class="main_section">
      <div class="header_button">
        <a href="<?php echo e(route('index_login')); ?>" class="menu_button">
          <button type="button" class="btn_format">Home</button>
        </a>
        <a href="<?php echo e(route('index_login')); ?>" class="menu_button">
          <button type="button" class="btn_format">Satta King</button>
        </a>
        <a href="<?php echo e(url('contact-us')); ?>"class="menu_button">
          <button type="button" class="btn_format">Contact</button>
        </a>
        <a href="<?php echo e(url('satta-king-game-record-chart')); ?>" class="menu_button">
          <button type="button" class="btn_format">Satta Chart</button>
        </a>
      </div>
    </div>
  </section>
 



<?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/include/header.blade.php ENDPATH**/ ?>