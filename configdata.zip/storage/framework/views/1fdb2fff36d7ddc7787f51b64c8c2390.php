

<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/newstyle.css')); ?>">


<style>
    .text-center{
        text-align: center !important;
    }
    .text-custom {
        margin-top: 10px;
    font-size: 1em; /* Base font size */
    padding: 0 1em; /* Base padding */
    color: blue;
}
.my-font{
    font-size:30px;
}

/* You can add media queries for specific screen sizes if needed */
@media screen and (min-width: 768px) {
    .text-custom {
        font-size: 1.2em; /* Adjust font size for larger screens */
        padding: 0 1.5em; /* Adjust padding for larger screens */
    }



}

@media screen and (min-width: 1024px) {
    .text-custom {
        font-size: 0.5em; /* Adjust font size for extra-large screens */
        padding: 0 2em; /* Adjust padding for extra-large screens */
    }
}


.text-custom-data{
    font-size:30px;
    /* font-size:32px; */
    /* padding: 18px; */
}
.text-size{
    font-size:15px;
    padding: 18px;
    text-align: center !important;
    color: red;
}
.text-back{
    background-color: yellow;
    padding: 10px;
}
.text-link{
    font-size:12px;
    padding: 18px;
    color:black;
}
.text-padding{
    padding:0 150;
}
/* Media query for even smaller screens */
@media only screen and (max-width: 480px) {
 
 .footer_section {
     width: 50%;
     display: flex;
     justify-content: center;
     gap: 5px;
     flex-wrap: wrap;
 }    .my-font,.text-custom-data{
    font-size:22px;
}

 }
 
</style>
<?php
    
$current_year = date('Y');
?>

  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <p class="Satta_king_content">
        Satta King 786

      </p>

    </div>
  </section>
  
<!-- satta king 786 content text -->
<div class="contact-satta">
      <p class="contact-heading">Gali Disawar Leak Jodi Chart</p>
      <p class="contact-text">09xxxxxx42</p>
      <p class="contact-text"> Raazdeep Tiwary</p>
      <div class="btn_section">
        <div class="phone_button">
          <button type="button" class="call-button">

            Call Now</button>
        </div>

        <div class="phone_button">
          <button type="button" class="whatsapp-button">
            WhatsApp Msg</button>
        </div>
      </div>
    </div> 


 
<!-- marquee section -->
<div class="text_slide"  >
  <marquee>
    <h5 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
    Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
    Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king <?php echo e($current_year); ?>, 786 satta king, Satta king game</h5>
  </marquee>
</div>
  <div class="text_slide">

      <div class="text-center mt-2">
     <h1 class="my-font">  Satta Record Chart for <?php echo e($current_year); ?> of Gali, Disawar, Faridabad and Ghaziabad Satta
     </h1>
    <p class="text-custom" style="">satta-king-786.org is the official website for showing Satta Record Charts for <?php echo e($current_year); ?> verified from satta company office, here you can find the record charts for Gali Satta record chart <?php echo e($current_year); ?>, Disawar Satta record chart <?php echo e($current_year); ?>, Faridabad Satta record chart <?php echo e($current_year); ?> and Ghaziabad Satta record chart <?php echo e($current_year); ?></p>
      <h2 class="text-custom-data">
        Official Satta Record Chart for <?php echo e($current_year); ?> of Gali and Satta King 786 Charts of <?php echo e($current_year); ?> for Disawar, Faridabad, Ghaziabad and Gali Direct from Company Office   
    </h2>     
    <div>

        
    </div>
  
</div>
  </div>

 
 
  

  <!-- Admin Game Start -->
  
  
  <!-- Admin Game End -->
  
  


  

 <!-- result section end -->


 
  



  <!-- record chart -->



    <?php
        $currentYear = now()->year;
        $groupedData = collect($uniqueDates)->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date)->format('F Y');
        });

        $currentMonth = null;
    ?>

    <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $dates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $firstDate = \Carbon\Carbon::parse($dates->first());
            $year = $firstDate->year;
        ?>

        <?php if($year == $currentYear): ?>
       

        <div style=" overflow: auto;">
            <table id="customers">
              
                    <tr id="newformate">
                        <th >
                            Date
                        </th>
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th >
                                <?php echo e($result); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
               
                <tbody>
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $dateCarbon = \Carbon\Carbon::parse($date);
                        ?>

                        <tr                     
                    >
                            <td class="mydate">
                                <?php echo e($dateCarbon->format('d-M-y')); ?>

                            </td>

                            <?php
                            $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                ->where('date', $date)
                                ->get()
                                ->keyBy('game_fk_id');
                            ?>
                        
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $result = $results->get($gameId);
                            ?>
                            <td class="">
                                <?php if($result): ?>
                                    <?php echo e($result->result); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            
                        
                        
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php
                        $currentMonth = $month;
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!is_null($currentMonth)): ?>
                </tbody>
            </table>
    
        <?php endif; ?>
        </div>


    <section>

  
  
        <?php if(count($gameresultsdata) > 0): ?>
          <?php
              $sortedYears = collect($gameresultsdata)->keys()->sort();
          ?>
    
          <?php $__currentLoopData = $sortedYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($loop->iteration >= count($sortedYears) - 2): ?>
                  <?php
                      $results = $gameresultsdata[$year];
                      $uniqueGames = collect($results)->unique('game.name');
                      $previousYear = null;
                  ?>
    
                  <?php if($uniqueGames->isNotEmpty()): ?>
    
                      <?php if($loop->first): ?>
                          <div class="new-div-class">
                              <p>Additional Text for the first year</p>
                          </div>
                      <?php endif; ?>
    
                      <?php $__currentLoopData = $uniqueGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                          $currentDate = new DateTime($result['date']);
                          $gameId = $result['game']['id'] ?? null;
                          ?>
    
                          <?php if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74])): ?>
                          <div class="newchart text-black">
                            <p class="newchart_content">
                                     <a style="text-decoration: none; color: black;" href="<?php echo e(route('new_page_year',['year'=> $year])); ?>">SATTA KING RECORD CHART  <?php echo e($year); ?></a></p>
                              </div>
                          <?php endif; ?>
    
                          
                          <?php
                              $previousYear = $currentDate->format('Y');
                          ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
              <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
          <p class="text-black">No game results available for the current year.</p>
      <?php endif; ?>
    
    
    
    
      </section>
  


    <?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/gamedata/index.blade.php ENDPATH**/ ?>