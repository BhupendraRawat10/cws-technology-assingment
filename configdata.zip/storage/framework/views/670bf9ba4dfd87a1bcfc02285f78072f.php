<!DOCTYPE html>
<html lang="en">


<!-- datatables.html  21 Nov 2019 03:55:21 GMT -->
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <!-- General CSS Files -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/cdbootstrap/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/cdbootstrap/css/cdb.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/app.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/bundles/datatables/datatables.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('public/assets/bundles/izitoast/css/iziToast.min.css')); ?>">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.4/jquery-confirm.min.css">

  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/custom.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/components.css')); ?>">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/custom.css')); ?>">
  
</head>
<style>
  .selected {
    background-color: #6777ef  !important;
    color: white !important;
}

.dropdown{
  padding:1px !important;
}

</style>

<body>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar sticky">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
									collapse-btn"> <i data-feather="align-justify"></i></a></li>
            <li><a href="#" class="nav-link nav-link-lg fullscreen-btn"> <i data-feather="maximize"></i> </a></li>
          </ul>
        </div>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown">
            <a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user"> 
              <?php if(auth()->guard()->check()): ?>
              
              <img alt="image" src="<?php echo e(Auth::user()->profile ? asset('public/assets/images/' . Auth::user()->profile) : asset('public/assets/img/admin.jpg')); ?>" class="user-img-radious-style " style="
              width: 50px;
          ">

              <?php endif; ?>      
               <span class="d-sm-none d-lg-inline-block"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right pullDown">
              <div class="dropdown-title">
                <?php if(auth()->guard()->check()): ?>
                Welcome, <?php echo e(Auth::user()->name); ?>

            <?php endif; ?>
            </div>
              <a href="<?php echo e(url('logout')); ?>" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="#"> 
              
              <span
                class="logo-name">Game</span>
            </a>
          </div>
          <ul class="sidebar-menu">
              <li class="dropdown">
                  <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-home"></i><span>Dashboard</span></a>    
              </li>
              
           
              <li class="dropdown">
                <a href="#" class="menu-toggle nav-link has-dropdown">
                  
                  <i class="
                  fa fa-bars"></i>
                    <span>Game Data  </span></a>
                <ul class="dropdown-menu">
                
                        <li><a class="nav-link" href="<?php echo e(route('admin.admin_game')); ?>">Add New</a></li>
                        <li><a class="nav-link" href="<?php echo e(route('admin.show_all_game')); ?>">Show</a></li>

                </ul>
              </li>
              <li class="dropdown">
                <a href="#" class="menu-toggle nav-link has-dropdown">
                  
                  <i class="
                  fa fa-bars"></i>
                    <span>Game Result  </span></a>
                <ul class="dropdown-menu">
                
                        <li><a class="nav-link" href="<?php echo e(route('admin_game_result')); ?>">Add New</a></li>
                        <li><a class="nav-link" href="<?php echo e(route('show_all_GameResult')); ?>">Show</a></li>

                 

                </ul>
              </li>
          
          </ul>
        </aside>
      </div><?php /**PATH C:\xampp\htdocs\wellknown\resources\views/admin/include/header.blade.php ENDPATH**/ ?>