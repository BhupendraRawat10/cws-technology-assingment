
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/newstyle.css')); ?>">
<style>
    .table-responsive {
    overflow-x: auto;
    width: 100%;
    max-width: 100%;
}

#customers {
    width: 100%;
}
Overflow-y:scroll;

#customers th,
#customers td {
    white-space: nowrap;
}
.text-padding {
    padding: 0 100;
}
.text-back {
    border-radius: 5px; /* Add border-radius for some rounded corners */
}

.text-link {
    margin: 0; /* Reset margin */
}

/* Media query for even smaller screens */
@media only screen and (max-width: 480px) {
 
.footer_section {
    width: 50%;
    display: flex;
    justify-content: center;
    gap: 5px;
    flex-wrap: wrap;
}
}

/* Adjust other styles as needed */

</style>
<section>

    <div class="Satta_king">
        <h1 class="Satta_king_content">
            <?php echo e($gamename); ?> SATTA KING RECORD CHART <?php echo e($gameyear); ?>


        </h1>

    </div>
    <div class="text_slide"  >
        <marquee>
          <h5 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
          Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
          Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king 2024, 786 satta king, Satta king game</h5>
        </marquee>
      </div>
        <div class="text_slide">
      
            <div class="text-center mt-2">
           <h2  style="font-size:2.5rem">  <?php echo e($gameyear); ?> <?php echo e($gamename); ?> Satta Record Chart and <?php echo e($gamename); ?> Satta Online Result <?php echo e($gameyear); ?>

           </h2>
          <p class="text-custom">We provide <?php echo e($gamename); ?> satta online record chart, here you can view detailed online satta record chart of <?php echo e($gamename); ?> Satta King <?php echo e($gameyear); ?>. This is chart is from trustworthy sources of <?php echo e($gamename); ?> Satta office . We promise to provide you fast <?php echo e($gamename); ?> satta results and <?php echo e($gamename); ?> Satta record charts along with many other online Satta games.</p>
          <h4 class="text-custom-data">
              Are you interested in viewing <?php echo e($gameyear); ?> genuine, fast and detailed <?php echo e($gamename); ?> Satta Record Chart?
            </h4>     
            <p class="text-custom">You're absolutely right. We pride ourselves on being the most accurate provider of <?php echo e($gameyear); ?> <?php echo e($gamename); ?> Satta record charts. All our records come online directly from the <?php echo e($gamename); ?> Satta office . When it comes to verified record charts for the year <?php echo e($gameyear); ?> <?php echo e($gamename); ?> Satta game, sattaking-online.in is the most trusted website.</p>
            <p class="text-custom">You can trust us to give you accurate <?php echo e($gamename); ?> Satta record charts straight from the company. At sattaking-online.in, we always make sure you get reliable information about the <?php echo e($gamename); ?> Satta game. You can count on us for honesty and clear updates every time.</p>
    
      
      </div>
        </div>  
</section>

<!-- Satta King Section -->
<div style=" overflow: auto;">
<table id="customers">
    <tr id="newformate">
        <th> Date </th>
        <?php for($month = 1; $month <= 12; $month++): ?>
            <th scope="col" class="px-6 py-3 border border-black text-center">
                <?php echo e(\Carbon\Carbon::create($gameyear, $month, 1)->format('M')); ?>

            </th>
        <?php endfor; ?>
    </tr>
    <tbody>
        <?php for($day = 1; $day <= 31; $day++): ?>
            <tr id="newformate">
                <th><?php echo e($day); ?></th>
                <?php for($innerMonth = 1; $innerMonth <= 12; $innerMonth++): ?>
                    <?php
                        $result = null;
                        $daysInMonth = \Carbon\Carbon::create($gameyear, $innerMonth, 1)->daysInMonth;
                        if ($day <= $daysInMonth) {
                            $formattedDate = \Carbon\Carbon::create($gameyear, $innerMonth, $day)->format('Y-m-d');
                            foreach ($dataes as $item) {
                                $result = $item->gameResults->firstWhere('date', $formattedDate);
                                if ($result) {
                                    break;
                                }
                            }
                        }
                    ?>

                    <td class="">
                        <?php echo e($result ? $result->result : '-'); ?>

                    </td>
                <?php endfor; ?>
            </tr>
        <?php endfor; ?>
    </tbody>

</table>
</div>
<?php echo $__env->make('frontend.gamedata.gamenameyear', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






</body>
<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/gamedata/gamealldata.blade.php ENDPATH**/ ?>