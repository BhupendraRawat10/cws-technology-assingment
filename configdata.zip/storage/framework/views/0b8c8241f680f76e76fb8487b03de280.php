<section>

  
  
    <?php if(count($gameresultsdata) > 0): ?>
      <?php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      ?>

      <?php $__currentLoopData = $sortedYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($loop->iteration >= count($sortedYears) - 2): ?>
              <?php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              ?>

              <?php if($uniqueGames->isNotEmpty()): ?>

                  <?php if($loop->first): ?>
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  <?php endif; ?>

                  <?php $__currentLoopData = $uniqueGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                  $currentDate = new DateTime($result['date']);
                  $gameId = $result['game']['id'] ?? null;
                  ?>

            

                  <?php if(in_array($gameId, [$gameIdvalue])): ?>
      
                  <div class="newchart text-black">
                    <p class="newchart_content">
                        <a style="text-decoration: none; color: black;" href="<?php echo e(route('new_page', ['year' => $year, 'name' => $result['game']['name']])); ?>">
                            <?php echo e($result['game']['name']); ?> Satta King Chart <?php echo e($currentDate ? $currentDate->format('Y') : ''); ?> 
                        </a>
                        <br>
                    </p>
                </div>
                  <?php endif; ?>
                  <?php
                      $previousYear = $currentDate->format('Y');
                  ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
      <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
  <p class="text-black">No game results available for the current year.</p>
<?php endif; ?>

</section><?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/gamedata/gamenameyear.blade.php ENDPATH**/ ?>