
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section>

    <div class="Satta_king">
        <h1 class="Satta_king_content">
            <?php echo e($gamename); ?> SATTA KING RECORD CHART <?php echo e($gameyear); ?>


        </h1>

    </div>
</section>

<!-- Satta King Section -->
<table id="customers">
    <tr id="newformate">
        <th> Date </th>
        <?php for($month = 1; $month <= 12; $month++): ?>
            <th scope="col" class="px-6 py-3 border border-black text-center">
                <?php echo e(\Carbon\Carbon::create($gameyear, $month, 1)->format('M')); ?>

            </th>
        <?php endfor; ?>
    </tr>

    <tbody>
        <?php for($day = 1; $day <= 31; $day++): ?>
            <tr id="newformate">
                <th><?php echo e($day); ?></th>
                <?php for($innerMonth = 1; $innerMonth <= 12; $innerMonth++): ?>
                    <?php
                        $result = null;
                        $daysInMonth = \Carbon\Carbon::create($gameyear, $innerMonth, 1)->daysInMonth;
                        if ($day <= $daysInMonth) {
                            $formattedDate = \Carbon\Carbon::create($gameyear, $innerMonth, $day)->format('Y-m-d');
                            foreach ($dataes as $item) {
                                $result = $item->gameResults->firstWhere('date', $formattedDate);
                                if ($result) {
                                    break;
                                }
                            }
                        }
                    ?>

                    <td class="">
                        <?php echo e($result ? $result->result : '-'); ?>

                    </td>
                <?php endfor; ?>
            </tr>
        <?php endfor; ?>
    </tbody>
</table>







</body>
<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/sattaki1/satta-king-786.org/resources/views/frontend/showdata.blade.php ENDPATH**/ ?>