
<meta name="description" content="Satta king 786 official provides the Satta king game live result 2024 with upcoming free guess Satta number gali satta, disawar satta, ghaziabad satta, faridabad satta, Black satta king 786, 
Satta 786, Delhi satta king, Satta king up, Satta king result, Satta bajar, Satta king chart, Black satta, Satta king 2024, Disawar satta king" />
<meta name="keywords" content="Satta king, Satta king fast, Sattaking, Satta king chart, Faridabad satta king, Satta bajar, Satta number, Satta king 786, Satta king gali disawar, Satta king result, Up satta king, Gali satta, 
Satta king live result, Ghaziabad satta king, Satta result, Satta king disawar, Satta 786" />
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/css/newstyle.css')); ?>">
<style>
   

.text-padding {
    padding: 0 100;
}
.text-back {
    border-radius: 5px; /* Add border-radius for some rounded corners */
}

.text-link {
    margin: 0; /* Reset margin */
}

/* Media query for smaller screens */
@media only screen and (max-width: 768px) {
    .text-padding {
        padding: 0 10; /* Reduce padding for smaller screens */
    }
  
    .text-link {
        font-size: 16px; /* Decrease font size for smaller screens */
    }
}

/* Media query for even smaller screens */
@media only screen and (max-width: 480px) {
    .text-padding {
        padding: 0 10; /* Further reduce padding for very small screens */
    }

    .text-link {
        font-size: 14px; /* Further decrease font size for very small screens */
    }
    .datetime_box{
        font-size: 25px !important;
    }
    .result_box {
    color: #fff;
    text-align: center;
    display: grid;
    grid-template-columns: auto !important;
}
.footer_section {
    width: 50%;
    display: flex;
    justify-content: center;
    gap: 5px;
    flex-wrap: wrap;
}
}
@media screen and (max-width: 600px) {
    .datetime_box {
      font-size: 14px; /* Adjust font size for smaller screens */
    }
  }

  table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        padding: 8px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #f2f2f2;
    }
    /* Responsive styles */
    @media only screen and (max-width: 200px) {
        table {
            border: 1px solid #ccc;
        }
        th, td {
            display: block;
            width: 100%;
        }
        tbody td:before {
            content: attr(data-label);
            font-weight: bold;
            float: left;
            text-transform: uppercase;
        }
    }
</style>
<?php
    
$current_year = date('Y');
?>

  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h4 class="Satta_king_content">
        Satta King 786

      </h4>

    </div>
  </section>
  
<!-- satta king 786 content text -->
<div class="contact-satta">
      <p class="contact-heading">Gali Disawar Leak Jodi Chart</p>
      <p class="contact-text">09xxxxxx42</p>
      <p class="contact-text"> Raazdeep Tiwary</p>
      <div class="btn_section">
        <div class="phone_button">
          <button type="button" class="call-button">

            Call Now</button>
        </div>

        <div class="phone_button">
          <button type="button" class="whatsapp-button">
            WhatsApp Msg</button>
        </div>
      </div>
    </div> 


 
<!-- marquee section -->

  <div class="text_slide">

      <div class="text-center mt-2">
     <h1  style="font-size:2.5rem">   Official <?php echo e($current_year); ?> Satta Reults for Satta King 786, Satta King Online, Black satta king and Satta king fast
     </h1>
    <p class="text-custom">सट्टा किंग मटका गेम्स के लिए भारत की पहली और एकमात्र Official वेबसाइट satta-king-786.org में सभी सट्टा किंग लवर्स का स्वागत है यहां आपको मिलेगा सट्टा किंग फील्ड से जुड़ी हर एक Update के साथ Super fast satta live result, Satta king record chart, Satta king 786, Gali satta, Satta king online, Satta king up, Disawar satta, Satta number, Black satta king, Satta king company, Up game king, Satta king live Result, Satta king news, Satta bazar, Gali result and more. हम अपने सट्टा किंग प्लेयर्स की जरुरतों को ध्यान में रखते हुए उनको ज्यादा से ज्यादा Profit कराने के लिए सट्टा लीक जोड़ी और आने वाले सट्टा नंबर की Winning के लिए अपने अनुभव और पुराने सट्टा रिकॉर्ड चार्ट की मदद से सट्टा ट्रिक्स व टिप्स भी प्रदान करते हैं।</p>
      <h2 class="text-custom-data">
        Satta King Online Results and Satta King 786 Charts of Apr 2024 for Gali satta, Delhi satta, Faridabad satta, Disawar satta, Black satta, Ghaziabad satta, Satta king up, Black satta king 786, Delhi disawar and Up satta king Direct from Satta King Company    
    </h2>     
    <div>

        <p class="text-size">सट्टा किंग गेम खेलने वाले सभी भाइयों के लिए ऑफर मिल रहा है अब डायरेक्ट सट्टा किंग ऑफिस से डेट फिक्स फाइनल कन्फर्म सिंगल जोड़ी में गेम लेने का और फ्रॉड सट्टा गेसर्स से बचने का क्योंकि कुछ लोग हमारा नाम लेकर सभी सट्टा प्लेयर्स के साथ धोखा कर रहे हैं। इसलिए जल्दी से जल्दी सट्टा ऑफिस में अपना रजिस्ट्रेशन कराएं और हमारे साथ बिजनेस करके प्रॉफिट ही प्रॉफिट कमाएं</p>
    </div>
    <div class="text-padding">
        <div class="text-back" style="background-color: #ffc107">
            <a style="text-decoration:none; display: block;" href="<?php echo e(route('admin.showalldata')); ?>">
                <p class="text-link" style="font-size: 20px; margin: 0;">
                    Click Here To See Official Satta Record Charts of 2024 for Gali satta king, Disawar satta king, Ghaziabad satta, Black satta king, Delhi satta king and Faridabad satta
                </p>
            </a>
        </div>
    </div>
    
</div>
  </div>
  <div class="text_slide">
    <marquee>
      <h3 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
      Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
      Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king 2024, 786 satta king, Satta king game</h3>
    </marquee>
  </div>

 
 
  

  <!-- Admin Game Start -->
  <section>
    <div class="datetime_section">
      <div id="datetime" class="datetime_box">

      </div>
    </div>

    <div class="text_section">

  <?php echo $__env->make('frontend.gamecode.gamename', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

  </section>
  
  <!-- Admin Game End -->
  
  


  <!-- result section -->
  <section>

   <div class="result_box">
    <?php echo $__env->make('frontend.gamecode.result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    </div>
  </section>

 <!-- result section end -->


 
 <?php
 $currentMonth = request()->has('month') ? request('month') : now()->format('F Y');
 $currentCarbon = \Carbon\Carbon::parse($currentMonth);
 $currentYear = $currentCarbon->year;
 
 $groupedData = collect($uniqueDates)->groupBy(function ($date) {
     return \Carbon\Carbon::parse($date)->format('F Y');
 });
 ?>
 
 <table id="customers">
     <tr id="newformate">
         <th>Date</th>
         <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <th><?php echo e($result); ?></th>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </tr>
     <tbody>
         <?php if($groupedData->has($currentMonth)): ?>
             <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $dates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php
                     $firstDate = \Carbon\Carbon::parse($dates->first());
                     $year = $firstDate->year;
                 ?>
 
                 <?php if($month === $currentMonth && $year == $currentYear): ?>
                     <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php
                             $dateCarbon = \Carbon\Carbon::parse($date);
                             $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                 ->where('date', $date)
                                 ->get()
                                 ->keyBy('game_fk_id');
                         ?>
                         <tr>
                             <td class="mydate"><?php echo e($dateCarbon->format('d-M-y')); ?></td>
                             <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php 
                                     $result = $results->get($gameId);
                                 ?>
                                 <td class="">
                                     <?php if($result): ?>
                                         <?php echo e($result->result); ?>

                                     <?php else: ?>
                                         -
                                     <?php endif; ?>
                                 </td>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php else: ?>
             <tr>
                 <td colspan="<?php echo e(count($uniqueGamesval) + 1); ?>" style="text-align: center;">No data available for <?php echo e($currentMonth); ?></td>
             </tr>
         <?php endif; ?>
     </tbody>
 </table>
 
 <?php
 $prevMonthName = $currentCarbon->copy()->subMonth()->format('F');
 $nextMonthName = $currentCarbon->copy()->addMonth()->format('F');
 ?>
 
 <div style="display: flex; justify-content: space-between;">
     <button class="btn btn-primary" style="width: 200px; margin: 12px; border-radius: 10px;">
         <a href="?month=<?php echo e($currentCarbon->copy()->subMonth()->format('F Y')); ?>" style="text-decoration: none; color:black; display: block; width: 100%; height: 100%;"> <?php echo e($prevMonthName); ?></a>
     </button>
     <button class="btn btn-primary" style="width: 200px; margin: 12px; border-radius: 10px;" >
         <a href="?month=<?php echo e($currentCarbon->copy()->addMonth()->format('F Y')); ?>" style="text-decoration: none; color:black; display: block; width: 100%; height: 100%;"> <?php echo e($nextMonthName); ?></a>
     </button>
 </div>
     

  <!-- record chart -->

  <section>

  
  
    <?php if(count($gameresultsdata) > 0): ?>
      <?php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      ?>

      <?php $__currentLoopData = $sortedYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($loop->iteration >= count($sortedYears) - 2): ?>
              <?php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              ?>

              <?php if($uniqueGames->isNotEmpty()): ?>

                  <?php if($loop->first): ?>
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  <?php endif; ?>

                  <?php $__currentLoopData = $uniqueGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      $currentDate = new DateTime($result['date']);
                      $gameId = $result['game']['id'] ?? null;
                      ?>

                      <?php if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74])): ?>
                 
                      <div class="newchart text-black">
                              <p class="newchart_content"> <a style="text-decoration: none; color: black;" href="<?php echo e(route('new_page_year',['year'=> $year])); ?>">SATTA KING RECORD CHART  <?php echo e($year); ?></a></p>
                          </div>
                      <?php endif; ?>

                      
                      <?php
                          $previousYear = $currentDate->format('Y');
                      ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
      <p class="text-black">No game results available for the current year.</p>
  <?php endif; ?>




  </section>


    <?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/index.blade.php ENDPATH**/ ?>