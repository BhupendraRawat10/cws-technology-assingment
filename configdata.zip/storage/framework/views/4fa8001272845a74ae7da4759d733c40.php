<?php
$current_time = now()->toDateString();
$previous_day = now()->subDay()->toDateString();

$games = \App\Models\Game::get();
?>

<?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
    $game_results = \App\Models\GameResult::where('game_fk_id', $game->id)
        ->whereIn('date', [$previous_day, $current_time])
        ->orderBy('date', 'asc') 
        ->get();

    $count = $game_results->count();
    ?>

    <div class="result_box_description">
        <p class="result_text"><?php echo e($game->name); ?></p>
        <a href="<?php echo e(route('game_record',['name' => $game->id])); ?>" class="" style="
            text-decoration: none;
            color: blue;
        ">Play Online</a>
        <p><?php echo e(\Carbon\Carbon::parse($game->open_time)->format('g:i A')); ?></p>

        <?php if($count > 0): ?>
            <div class="box_text">
                <?php $__currentLoopData = $game_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($result): ?>
                <?php if($loop->iteration == 1): ?>
                    <p class="result_number_old">(<?php echo e($result->result ?? '()'); ?>) <br> <span class="old">Old</span></p>
                <?php else: ?>
                <p class="result_number">[<?php echo e($result->result ?? '()'); ?>] <br> <span class="new">New</span></p>
                <?php endif; ?>
                    <div class="image_gif_parts">
                        <?php if($loop->iteration == 1): ?>
                            <img src="public/image/new.gif" class="image_gif" />
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <h6 class="result_number">[]</h6>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(count($game_results) == 1): ?>
            <p class="result_number">[]</p>
      
            <?php endif; ?>
            
    
          
          
                
            </div>
        <?php else: ?>
        <div class="box_text">
        <p class="result_number">()</p>
        
        <div class="image_gif_parts">
          <img src="public/image/new.gif" class="image_gif" />
        </div>
        
        <p class="result_number">()</p>
        </div>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\game\resources\views/frontend/gamecode/result.blade.php ENDPATH**/ ?>