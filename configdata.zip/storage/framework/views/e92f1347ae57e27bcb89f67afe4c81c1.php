<title>Sattaking | Satta king 786 | Satta result | Black satta king online | Satta bajar | Gali disawar satta</title>
<meta name="description" content="Satta king 786 official provides the Satta king game live result 2024 with upcoming free guess Satta number gali satta, disawar satta, ghaziabad satta, faridabad satta, Black satta king 786, 
Satta 786, Delhi satta king, Satta king up, Satta king result, Satta bajar, Satta king chart, Black satta, Satta king 2024, Disawar satta king" />
<meta name="keywords" content="Satta king, Satta king fast, Sattaking, Satta king chart, Faridabad satta king, Satta bajar, Satta number, Satta king 786, Satta king gali disawar, Satta king result, Up satta king, Gali satta, 
Satta king live result, Ghaziabad satta king, Satta result, Satta king disawar, Satta 786" />
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
        Satta King 786

      </h1>

    </div>
  </section>
  
<!-- satta king 786 content text -->
<div class="contact-satta">
      <p class="contact-heading">Gali Disawar Leak Jodi Chart</p>
      <p class="contact-text">09xxxxxx42</p>
      <p class="contact-text"> Raazdeep Tiwary</p>
      <div class="btn_section">
        <div class="phone_button">
          <button type="button" class="call-button">

            Call Now</button>
        </div>

        <div class="phone_button">
          <button type="button" class="whatsapp-button">
            WhatsApp Msg</button>
        </div>
      </div>
    </div> 


 
<!-- marquee section -->
  <div class="text_slide">
    <marquee>
      <h2 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
      Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
      Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king 2024, 786 satta king, Satta king game</h2>
    </marquee>
  </div>

 
 
  

  <!-- Admin Game Start -->
  <section>
    <div class="datetime_section">
      <div id="datetime" class="datetime_box">

      </div>
    </div>

    <div class="text_section">

  <?php echo $__env->make('frontend.gamecode.gamename', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

  </section>
  
  <!-- Admin Game End -->
  
  


  <!-- result section -->
  <section>

   <div class="result_box">
    <?php echo $__env->make('frontend.gamecode.result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    </div>
  </section>

 <!-- result section end -->


 
  



  <!-- record chart -->
  <section>

  
  
    <?php if(count($gameresultsdata) > 0): ?>
      <?php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      ?>

      <?php $__currentLoopData = $sortedYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($loop->iteration >= count($sortedYears) - 2): ?>
              <?php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              ?>

              <?php if($uniqueGames->isNotEmpty()): ?>

                  <?php if($loop->first): ?>
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  <?php endif; ?>

                  <?php $__currentLoopData = $uniqueGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      $currentDate = new DateTime($result['date']);
                      $gameId = $result['game']['id'] ?? null;
                      ?>

                      <?php if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74])): ?>
                      <div class="newchart-box">
                              <p class="">SATTA KING RECORD CHART  <?php echo e($year); ?></p>
                          </div>
                      <?php endif; ?>

                      <?php if(in_array($gameId, [2, 64, 68, 74])): ?>
                      
                      <div class="newchart text-black">
                        <p class="newchart_content">
                            <a style="text-decoration: none; color: black;" href="<?php echo e(route('new_page', ['year' => $year, 'name' => $result['game']['name']])); ?>">
                                <?php echo e($result['game']['name']); ?> Satta King Chart <?php echo e($currentDate ? $currentDate->format('Y') : ''); ?> 
                            </a>
                            <br>
                        </p>
                    </div>
                    
                      <?php endif; ?>

                      <?php
                          $previousYear = $currentDate->format('Y');
                      ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
      <p class="text-black">No game results available for the current year.</p>
  <?php endif; ?>




  </section>


    <?php
        $currentYear = now()->year;
        $groupedData = collect($uniqueDates)->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date)->format('F Y');
        });

        $currentMonth = null;
    ?>

    <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $dates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $firstDate = \Carbon\Carbon::parse($dates->first());
            $year = $firstDate->year;
        ?>

        <?php if($year == $currentYear): ?>
       

     
            <table id="customers">
              
                    <tr id="newformate">
                        <th >
                            Date
                        </th>
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th >
                                <?php echo e($result); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
               
                <tbody>
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $dateCarbon = \Carbon\Carbon::parse($date);
                        ?>

                        <tr                     
                    >
                            <td class="mydate">
                                <?php echo e($dateCarbon->format('d-M-y')); ?>

                            </td>

                            <?php
                            $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                ->where('date', $date)
                                ->get()
                                ->keyBy('game_fk_id');
                            ?>
                        
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $result = $results->get($gameId);
                            ?>
                            <td class="">
                                <?php if($result): ?>
                                    <?php echo e($result->result); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            
                        
                        
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php
                        $currentMonth = $month;
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!is_null($currentMonth)): ?>
                </tbody>
            </table>
    
        <?php endif; ?>
    



    
  


    <?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /home/sattaki1/satta-king-786.org/resources/views/frontend/index.blade.php ENDPATH**/ ?>