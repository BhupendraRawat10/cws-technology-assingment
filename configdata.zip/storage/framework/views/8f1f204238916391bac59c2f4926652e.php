<!DOCTYPE html>
<html lang="en">


<!-- auth-login.html  21 Nov 2019 03:49:32 GMT -->
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Otika - Admin Dashboard Template</title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/app.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/bundles/bootstrap-social/bootstrap-social.css')); ?>">
  <!-- Template CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/components.css')); ?>">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('public/assets/css/custom.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('public/assets/bundles/izitoast/css/iziToast.min.css')); ?>">

  
</head>

<body>
  <div class="loader"></div>
  <div id="app"><?php /**PATH C:\xampp\htdocs\wellknown\resources\views/include/header.blade.php ENDPATH**/ ?>