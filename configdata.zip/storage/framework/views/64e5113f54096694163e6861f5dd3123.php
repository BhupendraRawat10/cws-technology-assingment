<title>Satta bazar | Satta king chart | Gali satta | Satta king disawar | Satta record chart </title>
<meta name="description" content="Satta chart, Satta king delhi, Black satta, Satta king chart, Gali satta, Satta king online, Disawar satta, Ghaziabad satta, Satta king, Satta bajar, Disawar satta chart, Satta record satta, Gali satta king " />
<meta name="keywords" content="Satta king chart, Delhi satta, Satta record chart, Satta number, Satta king gali disawar, Satta bazar, Gali satta, Disawar satta, Ghaziabad satta, Gali disawar chart " />
<?php echo $__env->make('frontend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
    Satta King Chart
      </h1>

    </div>
  </section>
  



 <!-- record chart -->
  <section>

  
  
    <?php if(count($gameresultsdata) > 0): ?>
      <?php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      ?>

      <?php $__currentLoopData = $sortedYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($loop->iteration >= count($sortedYears) - 2): ?>
              <?php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              ?>

              <?php if($uniqueGames->isNotEmpty()): ?>

                  <?php if($loop->first): ?>
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  <?php endif; ?>

                  <?php $__currentLoopData = $uniqueGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php
                      $currentDate = new DateTime($result['date']);
                      $gameId = $result['game']['id'] ?? null;
                      ?>

                      <?php if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74])): ?>
                      <div class="newchart-box">
                              <p class="">Satta King Record Chart  <?php echo e($year); ?></p>
                          </div>
                      <?php endif; ?>

                      <?php if(in_array($gameId, [2, 64, 68, 74])): ?>
                      
                      <div class="newchart text-black">
                        <p class="newchart_content">
                            <a style="text-decoration: none; color: black;" href="<?php echo e(route('new_page', ['year' => $year, 'name' => $result['game']['name']])); ?>">
                                <?php echo e($result['game']['name']); ?> Satta King Chart <?php echo e($currentDate ? $currentDate->format('Y') : ''); ?> Record Chart <?php echo e($year ?? ''); ?>

                            </a>
                            <br>
                        </p>
                    </div>
                    
                      <?php endif; ?>

                      <?php
                          $previousYear = $currentDate->format('Y');
                      ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php else: ?>
      <p class="text-black">No game results available for the current year.</p>
  <?php endif; ?>




  </section>


    <?php
        $currentYear = now()->year;
        $groupedData = collect($uniqueDates)->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date)->format('F Y');
        });

        $currentMonth = null;
    ?>

    <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $dates): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $firstDate = \Carbon\Carbon::parse($dates->first());
            $year = $firstDate->year;
        ?>

        <?php if($year == $currentYear): ?>
       

     
            <table id="customers">
              
                    <tr id="newformate">
                        <th >
                            Date
                        </th>
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th >
                                <?php echo e($result); ?>

                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
               
                <tbody>
                    <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $dateCarbon = \Carbon\Carbon::parse($date);
                        ?>

                        <tr                     
                    >
                            <td >
                                <?php echo e($dateCarbon->format('d-M-Y')); ?>

                            </td>

                            <?php
                            $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                ->where('date', $date)
                                ->get()
                                ->keyBy('game_fk_id');
                            ?>
                        
                        <?php $__currentLoopData = $uniqueGamesval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameId => $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                                $result = $results->get($gameId);
                            ?>
                            <td class="">
                                <?php if($result): ?>
                                    <?php echo e($result->result); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            
                        
                        
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php
                        $currentMonth = $month;
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!is_null($currentMonth)): ?>
                </tbody>
            </table>
    
        <?php endif; ?>
    








  <!-- form section -->

<section class="bgwhite p4 m4_universal">
    <div>
    <p>
        Satta king, Black satta king, Satta number, Satta king 786, Black satta, Satta king fast, Satta disawar, Satta king black, Gali satta, Satta king up, Disawar satta, Satta king delhi, Satta result, Delhi satta king, Ghaziabad satta, Black satta king 786, Sattaking, Satta king online, Black satta chart, Satta king matka, Delhi satta, Up game king, Satta king gali disawar, Satta king fast result, Blacksatta king, Satta bajar, Satta king chart, Satta leak number, Disawar satta king, Satta 786


    </p>
    </div>
</section>






<?php echo $__env->make('frontend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sattaki1/satta-king-786.org/resources/views/frontend/satta-king-game-record-chart.blade.php ENDPATH**/ ?>