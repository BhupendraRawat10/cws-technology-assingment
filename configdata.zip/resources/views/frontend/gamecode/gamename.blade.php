@php
$today = now()->toDateString(); 
$gamesmyvariable = \App\Models\Game::whereIn('id', [2, 64, 68])
    ->where('Is_admin_game', 1)
    ->with(['gameResults' => function ($query) use ($today) {
        $query->whereDate('date', $today)->latest('date');
    }])
    ->get();
@endphp

@foreach ($gamesmyvariable as $game)
    <h3 class="result_parts_first">{{ $game->name }}</h3>
<a href="{{route('game_record',['name' => $game->id])}}" class="btn-info">Play Online</a>
    @forelse ($game->gameResults as $result)
        <div class="text_first">
            <pre class="text_first">{{ $result->result }}</pre>
        </div>
    @empty
        <p class="text_first">wait</p>
    @endforelse

    @if ($game->id === 74)
        <p class="text-2xl text-yellow">Hello</p>
    @endif
@endforeach



@php
  use Carbon\Carbon;
  $currentTime = Carbon::now();
  $targetTime = Carbon::createFromTime(10, 0, 0); // 10:00:00
  $isBeforeTargetTime = $currentTime->lessThan($targetTime);

  $yesterday = now()->subDay()->toDateString(); // Get yesterday's date

$gamesmyvariabledata =  \App\Models\Game::whereIn('id', [74]) 
->where('Is_admin_game', 1)
    ->with(['gameResults' => function ($query) use ( $yesterday) {
        $query->whereDate('date', $yesterday)
            ->latest('date');
    }])
    ->get();
@endphp
@foreach ($gamesmyvariabledata as $game)
  <h3 class="result_parts_first">{{ $game->name }}</h3>
  <a href="{{route('game_record',['name' => $game->id])}}" class="btn-info">Play Online</a>
  @if ($isBeforeTargetTime)
       @if ($game->gameResults && $game->gameResults->isNotEmpty())
          @foreach ($game->gameResults as $result)
              <div class="pt-2 text_first text-3xl">
                  <pre class="text-2xl text_first">{{ $result->result }}</pre>
              </div>
          @endforeach
      @else
          <p class="text_first">wait</p>
      @endif
  @else

      <p class="text_first">wait</p>
  @endif
@endforeach



