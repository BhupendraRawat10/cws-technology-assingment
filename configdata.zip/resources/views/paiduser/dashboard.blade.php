{{-- @include('admin.include.header') --}}
<title> Dashboard</title>
<style>
    .height
    {
        height: 115px;
    }
</style>
<h1>paid user</h1>
      <!-- Main Content -->
      {{-- <div class="main-content">
        <section class="section">
            <div class="row">
           
    
                <div class="col-xl-3 col-lg-6">
                  <div class="card">
                    <a href="#" class="text-decoration-none height">
                      <div class="p-t-20 d-flex justify-content-between">
                        <div class="col">
                          <h6 class="mb-0 font-13 col-black">ContactUs</h6>
                          <span class="font-weight-bold mb-0 font-20 col-green"> </span>
                        </div>
                      </div>
                    </a>
                  <div>
                </div>
              </div>
        </section>
      </div>
@include('admin.include.footer') --}}