{{-- <title>Sattaking | Satta king 786 | Satta result | Black satta king online | Satta bajar | Gali disawar satta</title> --}}
{{-- <meta name="description" content="Satta king 786 official provides the Satta king game live result 2024 with upcoming free guess Satta number gali satta, disawar satta, ghaziabad satta, faridabad satta, Black satta king 786, 
Satta 786, Delhi satta king, Satta king up, Satta king result, Satta bajar, Satta king chart, Black satta, Satta king 2024, Disawar satta king" />
<meta name="keywords" content="Satta king, Satta king fast, Sattaking, Satta king chart, Faridabad satta king, Satta bajar, Satta number, Satta king 786, Satta king gali disawar, Satta king result, Up satta king, Gali satta, 
Satta king live result, Ghaziabad satta king, Satta result, Satta king disawar, Satta 786" /> --}}
@include('frontend.include.header')
<link rel="stylesheet" href="{{ asset('public/css/newstyle.css') }}">


<style>
    .text-center{
        text-align: center !important;
    }
    .text-custom {
        margin-top: 10px;
    font-size: 1em; /* Base font size */
    padding: 0 1em; /* Base padding */
    color: blue;
}
.my-font{
    font-size:30px;
}

/* You can add media queries for specific screen sizes if needed */
@media screen and (min-width: 768px) {
    .text-custom {
        font-size: 1.2em; /* Adjust font size for larger screens */
        padding: 0 1.5em; /* Adjust padding for larger screens */
    }



}

@media screen and (min-width: 1024px) {
    .text-custom {
        font-size: 0.5em; /* Adjust font size for extra-large screens */
        padding: 0 2em; /* Adjust padding for extra-large screens */
    }
}


.text-custom-data{
    font-size:30px;
    /* font-size:32px; */
    /* padding: 18px; */
}
.text-size{
    font-size:15px;
    padding: 18px;
    text-align: center !important;
    color: red;
}
.text-back{
    background-color: yellow;
    padding: 10px;
}
.text-link{
    font-size:12px;
    padding: 18px;
    color:black;
}
.text-padding{
    padding:0 150;
}
/* Media query for even smaller screens */
@media only screen and (max-width: 480px) {
 
 .footer_section {
     width: 50%;
     display: flex;
     justify-content: center;
     gap: 5px;
     flex-wrap: wrap;
 }    .my-font,.text-custom-data{
    font-size:22px;
}

 }
 
</style>
@php
    
$current_year = date('Y');
@endphp

  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <p class="Satta_king_content">
        Satta King 786

      </p>

    </div>
  </section>
  
<!-- satta king 786 content text -->
<div class="contact-satta">
      <p class="contact-heading">Gali Disawar Leak Jodi Chart</p>
      <p class="contact-text">09xxxxxx42</p>
      <p class="contact-text"> Raazdeep Tiwary</p>
      <div class="btn_section">
        <div class="phone_button">
          <button type="button" class="call-button">

            Call Now</button>
        </div>

        <div class="phone_button">
          <button type="button" class="whatsapp-button">
            WhatsApp Msg</button>
        </div>
      </div>
    </div> 


 
<!-- marquee section -->
<div class="text_slide"  >
  <marquee>
    <h5 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
    Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
    Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king {{$current_year}}, 786 satta king, Satta king game</h5>
  </marquee>
</div>
  <div class="text_slide">

      <div class="text-center mt-2">
     <h1 class="my-font">  Satta Record Chart for {{$current_year}} of Gali, Disawar, Faridabad and Ghaziabad Satta
     </h1>
    <p class="text-custom" style="">satta-king-786.org is the official website for showing Satta Record Charts for {{$current_year}} verified from satta company office, here you can find the record charts for Gali Satta record chart {{$current_year}}, Disawar Satta record chart {{$current_year}}, Faridabad Satta record chart {{$current_year}} and Ghaziabad Satta record chart {{$current_year}}</p>
      <h2 class="text-custom-data">
        Official Satta Record Chart for {{$current_year}} of Gali and Satta King 786 Charts of {{$current_year}} for Disawar, Faridabad, Ghaziabad and Gali Direct from Company Office   
    </h2>     
    <div>

        {{-- <p class="text-size">सट्टा किंग गेम खेलने वाले सभी भाइयों के लिए ऑफर मिल रहा है अब डायरेक्ट सट्टा किंग ऑफिस से डेट फिक्स फाइनल कन्फर्म सिंगल जोड़ी में गेम लेने का और फ्रॉड सट्टा गेसर्स से बचने का क्योंकि कुछ लोग हमारा नाम लेकर सभी सट्टा प्लेयर्स के साथ धोखा कर रहे हैं। इसलिए जल्दी से जल्दी सट्टा ऑफिस में अपना रजिस्ट्रेशन कराएं और हमारे साथ बिजनेस करके प्रॉफिट ही प्रॉफिट कमाएं</p> --}}
    </div>
  
</div>
  </div>

 
 
  

  <!-- Admin Game Start -->
  {{-- <section>
    <div class="datetime_section">
      <div id="datetime" class="datetime_box">

      </div>
    </div>

    <div class="text_section">

  @include('frontend.gamecode.gamename')

    </div>

  </section> --}}
  
  <!-- Admin Game End -->
  
  


  {{-- <!-- result section -->
  <section>

   <div class="result_box">
    @include('frontend.gamecode.result')

    
    </div>
  </section> --}}

 <!-- result section end -->


 
  



  <!-- record chart -->



    @php
        $currentYear = now()->year;
        $groupedData = collect($uniqueDates)->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date)->format('F Y');
        });

        $currentMonth = null;
    @endphp

    @foreach($groupedData as $month => $dates)
        @php
            $firstDate = \Carbon\Carbon::parse($dates->first());
            $year = $firstDate->year;
        @endphp

        @if($year == $currentYear)
       

        <div style=" overflow: auto;">
            <table id="customers">
              
                    <tr id="newformate">
                        <th >
                            Date
                        </th>
                        @foreach($uniqueGamesval as $gameId => $result)
                            <th >
                                {{ $result }}
                            </th>
                        @endforeach
                    </tr>
               
                <tbody>
                    @foreach($dates as $date)
                        @php
                            $dateCarbon = \Carbon\Carbon::parse($date);
                        @endphp

                        <tr                     
                    >
                            <td class="mydate">
                                {{ $dateCarbon->format('d-M-y') }}
                            </td>

                            @php
                            $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                ->where('date', $date)
                                ->get()
                                ->keyBy('game_fk_id');
                            @endphp
                        
                        @foreach($uniqueGamesval as $gameId => $gameName)
                            @php 
                                $result = $results->get($gameId);
                            @endphp
                            <td class="">
                                @if($result)
                                    {{ $result->result }}
                                @else
                                    -
                                @endif
                            </td>
                        @endforeach
                        
                            
                        
                        
                        </tr>
                    @endforeach

                    @php
                        $currentMonth = $month;
                    @endphp
                @endif
            @endforeach

            @if(!is_null($currentMonth))
                </tbody>
            </table>
    
        @endif
        </div>


    <section>

  
  
        @if(count($gameresultsdata) > 0)
          @php
              $sortedYears = collect($gameresultsdata)->keys()->sort();
          @endphp
    
          @foreach($sortedYears as $year)
              @if($loop->iteration >= count($sortedYears) - 2)
                  @php
                      $results = $gameresultsdata[$year];
                      $uniqueGames = collect($results)->unique('game.name');
                      $previousYear = null;
                  @endphp
    
                  @if($uniqueGames->isNotEmpty())
    
                      @if($loop->first)
                          <div class="new-div-class">
                              <p>Additional Text for the first year</p>
                          </div>
                      @endif
    
                      @foreach($uniqueGames as $result)
                          <?php
                          $currentDate = new DateTime($result['date']);
                          $gameId = $result['game']['id'] ?? null;
                          ?>
    
                          @if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74]))
                          <div class="newchart text-black">
                            <p class="newchart_content">
                                     <a style="text-decoration: none; color: black;" href="{{route('new_page_year',['year'=> $year])}}">SATTA KING RECORD CHART  {{ $year }}</a></p>
                              </div>
                          @endif
    
                          {{-- @if(in_array($gameId, [2, 64, 68, 74]))
                          
                          <div class="newchart text-black">
                            <p class="newchart_content">
                                <a style="text-decoration: none; color: black;" href="{{ route('new_page', ['year' => $year, 'name' => $result['game']['name']]) }}">
                                    {{ $result['game']['name'] }} Satta King Chart {{ $currentDate ? $currentDate->format('Y') : '' }} 
                                </a>
                                <br>
                            </p>
                        </div>
                          @endif --}}
                          @php
                              $previousYear = $currentDate->format('Y');
                          @endphp
                      @endforeach
                  @endif
              @endif
          @endforeach
      @else
          <p class="text-black">No game results available for the current year.</p>
      @endif
    
    
    
    
      </section>
  


    @include('frontend.include.footer')

