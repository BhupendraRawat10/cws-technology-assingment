<style>
  .button_format_footer {
    background-color: #ffe87c;
    font-size: 20px;
    border: none;
    color: #ff0000;
    font-weight: 700;
    cursor: pointer;
}
@media only screen and (max-width: 480px) {
 
 .footer_section {
     width: 50%;
     display: flex;
     justify-content: center;
     gap: 5px;
     flex-wrap: wrap;
 }

 }
</style>
<section>
  <div class="footer-section">
    <div class="footer_section">

      <a  href="{{route('index_login')}}" class="footer_button">
        <button type="button" class="button_format_footer">Home</button>
    </a>
        
        <a href="{{route('game_login')}}" class="footer_button">
      <button type="button"  class="button_format_footer">Login</button>
      </a>
      
      <a href="{{url('contact-us')}}" class="footer_button">
      <button type="button" class="button_format_footer">Contact</button>
      </a>
        <a href="{{url('about-us')}}" class="footer_button">
      <button type="button" class="button_format_footer">About</button>
      </a>
         <a href="{{url('disclaimer')}}" class="footer_button">
      <button type="button" class="button_format_footer">Disclaimer</button>
      </a>
      
      <a href="{{route('game_register')}}" class="footer_button">
      <button type="button" class="button_format_footer">Registration</button>
      </a>
      
    </div>

</section>

<section>
  <div class="contact-part">
    <p class="footer-text"> © All Right Reserved - 2023</p>

    <p class="footer-text"> CONTACT (ADMIN)</p>

    <p class="footer-text"> 085XXXXXX42</p>
  </div>
</section>

  <!-- footer section -->









</body>

</html> 