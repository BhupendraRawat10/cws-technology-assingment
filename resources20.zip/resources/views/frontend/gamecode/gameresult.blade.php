@php
$current_time = now()->toDateString();
$previous_day = now()->subDay()->toDateString();

$gameresults = \App\Models\GameResult::with('game')
    ->whereDate('date', $previous_day)
    ->orWhereDate('date', $current_time)
    ->get()
    ->groupBy('game_fk_id');
@endphp


    @foreach ($gameresults as $game_fk_id => $results)
    <div class="result_box_description">
        <h5 class="result_text">{{ $results->first()->game->name }}</h5>

         <h3> {{ \Carbon\Carbon::parse($results->first()->game->open_time)->format('g:i A') }}
         </h3>
      
         
         <div class="box_text">
              <h6 class="result_number">({{ $results->first()->result }})</h6>
              @if ($results->count() > 1)
                <div class="image_gif_parts">
                 <image src="public/image/new.gif" class="image_gif" />
                 </div>
              <p class="box_text_description">({{ $results->values()[1]->result }})</p>
               @else
               <div class="image_gif_parts">
                 <image src="public/image/new.gif" class="image_gif" />
                 </div>
                   <p class="box_text_description">[]</p>
            @endif

    </div>
    </div>
   @endforeach