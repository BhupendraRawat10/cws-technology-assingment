<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\GameController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
  
// Route::get('/', function () {
//     return view('welcome');
// });

// frontend
Route::get('/', [FrontendController::class, 'index_login'])->name('index_login');
Route::get('record-new-page/{year}/{name}', [FrontendController::class, 'new_page'])->name('new_page');
Route::get('record-new-page-year/{year}', [FrontendController::class, 'new_page_year'])->name('new_page_year');
Route::get('game-record/{name}', [FrontendController::class, 'game_record'])->name('game_record');

////Additional Pages
Route::get('/about-us', [FrontendController::class, 'about_us']);
Route::get('/paid-login', [FrontendController::class, 'paid_login']);
Route::get('/contact-us', [FrontendController::class, 'contact_us']);
Route::get('/disclaimer', [FrontendController::class, 'disclaimer']);
Route::get('/privacy-policy', [FrontendController::class, 'privacy_policy']);
Route::get('/ghaziabad-satta-king', [FrontendController::class, 'ghaziabad_satta_king']);
Route::get('/satta-king-chart-2020', [FrontendController::class, 'sattakingchart2020']);
Route::get('/satta-king-chart-2021', [FrontendController::class, 'sattakingchart2021']);
Route::get('/satta-king-chart-2022', [FrontendController::class, 'sattakingchart2022']);
Route::get('/satta-king-game-record-chart', [FrontendController::class, 'sattakinggamerecordchart']);
Route::get('/satta-king-online-sattaking-gali-disawar-number', [FrontendController::class, 'sattakingonlinesattakinggalidisawarnumber']);
Route::get('/satta-record-chart2021', [FrontendController::class, 'sattarecordchart2021']);
Route::get('/satta-record-chart2022', [FrontendController::class, 'sattarecordchart2021']);
Route::get('/show-game-data',[FrontendController::class,'showalldata'])->name('admin.showalldata');

// login
Route::get('game-login', [FrontendController::class, 'game_login'])->name('game_login');
Route::get('game-register', [FrontendController::class, 'game_register'])->name('game_register');

Route::get('login', [AuthController::class,'login'])->name('login');
Route::post('login-submit', [AuthController::class, 'login_submit'])->name('login_submit');
Route::get('logout', [AuthController::class, 'logout'])->name('logout');


////// Admin Routes
Route::group(['middleware' => 'auth'], function () {
    Route::get('dashboard', [AuthController::class, 'dashboard'])->name('admin.dashboard');
    
    // add game
    Route::get('admin-game-add', [GameController::class, 'admin_game'])->name('admin.admin_game');
    Route::post('admin-game-add-data', [GameController::class, 'add_game'])->name('admin.add_game');
    Route::get('show-all-game', [GameController::class, 'show_all_game'])->name('admin.show_all_game');
    Route::post('show-all-game-show', [GameController::class, 'show_all_game_data'])->name('admin.show_all_game_data');
    Route::get('edit-game/{id}', [GameController::class, 'edit_data_game'])->name('admin.edit_data_game');
    Route::post('edit-game-update', [GameController::class, 'update_game_data'])->name('admin.update_game_data');
    Route::post('game-delete', [GameController::class, 'delete_game'])->name('admin.delete_game');
    Route::post('game-checkboxdata', [GameController::class, 'checkboxdata'])->name('admin.checkboxdata');
    // add game 
    Route::get('game-result-add', [GameController::class, 'admin_game_result'])->name('admin_game_result');
    Route::post('game-result-add-data', [GameController::class, 'add_GameResult'])->name('add_GameResult');
    Route::get('game-result-data-show', [GameController::class, 'show_all_GameResult'])->name('show_all_GameResult');
    Route::post('game-result-data-show-all', [GameController::class, 'show_all_GameResult_data'])->name('show_all_GameResult_data');
    Route::get('game-result-data-edit/{id}', [GameController::class, 'edit_data_GameResult'])->name('edit_data_GameResult');
    Route::post('game-result-data-update', [GameController::class, 'update_GameResult_data'])->name('update_GameResult_data');
    Route::post('game-result-data-delete', [GameController::class, 'delete_GameResult'])->name('delete_GameResult');

    // changes 17-04-2024


});





Route::group(['middleware' => 'paiduser'], function () {
    Route::get('paid_dashboard', [AuthController::class, 'paid_dashboard'])->name('paiduser.dashboard');
});
Route::group(['middleware' => 'guest'], function () {
    Route::get('guset_dashboard', [AuthController::class, 'guset_dashboard'])->name('guest.dashboard');
});