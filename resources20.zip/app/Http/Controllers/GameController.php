<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\GameResult;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class GameController extends Controller
{
    public function admin_game()
    {
        return view("admin.gamedata.create");
    }
    public function add_game(Request $request)
    {
        // return $request->all();
        $rules = [
            'Name'   => 'required',
            'time'=> 'required',
           
     
        ];
    
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'message' => $validator->errors()->first()]);
        }

        
        $data = [
            'name'   => $request->input('Name'),
            'open_time'   => $request->input('time'),
      
         
        ];
        
        $recentWorks = new Game();
        $insert = $recentWorks->insert($data);
        
        if ($insert) {
            return response()->json(['status' => true, 'location' => route('admin.show_all_game'), 'message' => 'Data added to the table successfully!']);
        } else {
            return response()->json(['status' => false, 'message' => 'Something Went Wrong!']);
        }
    } 
    public function show_all_game()
    {
       return view('admin.gamedata.index');
    }
    
    public function show_all_game_data(Request $request)
    {
      
           if (isset($request->search['value'])) {
               $search = $request->search['value'];
           } else {
               $search = '';
           }
           if (isset($request->length)) {
               $limit = $request->length;
           } else {
               $limit = 10;
           }
           if (isset($request->start)) {
               $ofset = $request->start;
           } else {
               $ofset = 0;
           }
           $orderType = $request->order[0]['dir'];
           $nameOrder = $request->columns[$request->order[0]['column']]['name'];
       
           $total = Game::select('games.*')
           ->where(function ($query) use ($search) {
               $query->orWhere('games.name', 'like', '%' . $search . '%');
           
           });
           $total = $total->count();
       
           $books = Game::select('games.*')
           ->where(function ($query) use ($search) {
               $query->orWhere('games.name', 'like', '%' . $search . '%');
           })
           ->orderBy( $nameOrder, $orderType)
           ->limit($limit)
           ->offset($ofset)
           ->get();
       
           $i = 1 * $ofset;
           $data = [];
       
           foreach ($books as $key => $item) {
            $action = '
      
            <a href="' . route('admin.edit_data_game', $item->id) . '" class="p-2 bg-warning text-white" id="editClient" style="margin: 5px;">
                <i class="fa fa-edit"></i>
            </a>
            <button class="px-2 py-0 btn-danger customerDelete rounded mt-2" data-id="' . $item->id . '">
                <i class="fas fa-trash" aria-hidden="true"></i>
            </button>';
        
               $image = '<img src="public/application/' . $item->image . '" alt="Item Image" width="80">';
               $profile = '<img src="public/application/' . $item->doctor_image . '" alt="Item Image" width="80">';

               if ($item->Is_admin_game == '0') {
                $gamestatus = '<input type="checkbox" class="checkbox-class checkboxdata" name="selected_items[]" data-id="' . $item->id . '">';
            } else {
                // Change the content in the else block as needed
                $gamestatus = '<input type="checkbox" class="admin-checkbox-class checkboxdata" name="selected_items[]" data-id="' . $item->id . '" checked>';
            }
            
               
               $data[] = array(
                   $i + $key + 1,

                   $item->name,
                   $item->open_time,
                //    $item->open_time,
             
                 $gamestatus,
                   $action,
               );
           }        
           // Session::put('filter',$request->all());
           $records['recordsTotal'] = $total;
           $records['recordsFiltered'] = $total;
           $records['data'] = $data;
           echo json_encode($records);
  
   
    }
    public function checkboxdata(Request $request)
    {
         $data= Game::find($request->id);
        if($data->Is_admin_game == '0')
        {
                $data->Is_admin_game='1';
            }
            else{
                
                $data->Is_admin_game='0';
        }
        $data->save();
        if ($data->save()) {
            return response()->json(['status' => true, 'message' => "Data update Successfully"]);
        } else {
            return response()->json(['status' => false, 'message' => "Error Occurred, Please try again"]);
        }
    }
    public function edit_data_game($id)
    {
            $data= Game::find($id);
            return view("admin.gamedata.edit",compact('data'));
    }
    public function update_game_data(Request $request)
    {
        // return $request->all();
       $updatedata = Game::find($request->id);

       $data = [
        'name'   => $request->input('game_name'),
        'open_time'   => $request->input('opentime'),
       
     
    ];
    
$updatedata->update($data);

if ($updatedata) {
   return response()->json(['status' => true, 'location' => route('admin.show_all_game'), 'message' => 'Data update to the table successfully!']);
} else {
   return response()->json(['status' => false, 'message' => "Error Occurred, Please try again"]);
}
    }
    public  function delete_game(Request $request)
    {
       $delete = Game::where('id', $request->id)->delete();
  
       if ($delete) {
           return response()->json(['status' => true, 'message' => "Data Deleted Successfully"]);
       } else {
           return response()->json(['status' => false, 'message' => "Error Occurred, Please try again"]);
       }
    }


    // game result
    public function admin_game_result()
    {
        $game = Game::get();
            //   $game = Game::where('Is_admin_game', 1)->get();

        return view("admin.gameresult.create",compact('game'));
    }
    public function add_GameResult(Request $request)
    {
    //   return $request;
        $gameId = $request->input('game_fk_id');
        $date = $request->input('date');
        
        $statement = GameResult::where('game_fk_id', $gameId)
                                ->where('date', $date)
                                ->first();
        
        if ($statement) {
            return response()->json(['status' => false, 'message' => 'Today Date game all so updated!']);
        } else {
       
        
        
        
    
        

    
        $rules = [
            'game_fk_id' => 'required',

            'Result' => 'required',
            'date' => 'required',
        ];
        // $rules = [
        //     'game_fk_id' => 'required|unique:game_results',

        //     'Result' => 'required',
        //     'date' => 'required|unique:game_results',
        // ];
        

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'message' => $validator->errors()->first()]);
        }
       
        
        $data = [
            'result'   => $request->input('Result'),
            'date'   => $request->input('date'),
            'game_fk_id'   => $request->input('game_fk_id'),
      
         
        ];
        
        $recentWorks = new GameResult();
        $insert = $recentWorks->insert($data);
        
        if ($insert) {
            return response()->json(['status' => true, 'location' => route('show_all_GameResult'), 'message' => 'Data added to the table successfully!']);
        } else {
            return response()->json(['status' => false, 'message' => 'Something Went Wrong!']);
        }
        }
    } 
    public function show_all_GameResult()
    {
       return view('admin.gameresult.index');
    }
    
    public function show_all_GameResult_data(Request $request)
    {
      
           if (isset($request->search['value'])) {
               $search = $request->search['value'];
           } else {
               $search = '';
           }
           if (isset($request->length)) {
               $limit = $request->length;
           } else {
               $limit = 10;
           }
           if (isset($request->start)) {
               $ofset = $request->start;
           } else {
               $ofset = 0;
           }
           $orderType = $request->order[0]['dir'];
           $nameOrder = $request->columns[$request->order[0]['column']]['name'];
       
           $total = GameResult::select('game_results.*')
           ->where(function ($query) use ($search) {
               $query->orWhere('game_results.result', 'like', '%' . $search . '%');
           
           });
           $total = $total->count();
       
           $books = GameResult::select('game_results.*')
           ->where(function ($query) use ($search) {
               $query->orWhere('game_results.result', 'like', '%' . $search . '%');
           })
           ->orderBy( $nameOrder, $orderType)
           ->limit($limit)
           ->offset($ofset)
           ->get();
       
           $i = 1 * $ofset;
           $data = [];
       
           foreach ($books as $key => $item) {
               $action = '
               
                  <a href="' . route('edit_data_GameResult', $item->id) . '"class=" p-2 bg-warning  text-white" id="editClient" style="margin: 5px;"><i class="fa fa-edit"></i></a>
               <button class="px-2 py-0 btn-danger customerDelete rounded mt-2" data-id="' . $item->id . '">   <i class="fas fa-trash" aria-hidden="true"></i>  </button>';
               // $petrolpump = HomePage::pluck('name','id');

               $image = '<img src="public/application/' . $item->image . '" alt="Item Image" width="80">';
               $profile = '<img src="public/application/' . $item->doctor_image . '" alt="Item Image" width="80">';

        $gamename=Game::find( $item->game_fk_id);

               $data[] = array(
                   $i + $key + 1,

                   $gamename->name ,
                   $item->result,
                   $item->date ,
             
               
                   $action,
               );
           }        
           $records['recordsTotal'] = $total;
           $records['recordsFiltered'] = $total;
           $records['data'] = $data;
           echo json_encode($records);
  
   
    }
    public function edit_data_GameResult($id)
    {
            $data= GameResult::find($id);
            $game= Game::all();
            return view("admin.gameresult.edit",compact('data','game'));
    }
    public function update_GameResult_data(Request $request)
    {
        // return $request->all();
       $updatedata = GameResult::find($request->id);

       $data = [
    
        'result'   => $request->input('Result'),
        'date'   => $request->input('date'),
        'game_fk_id'   => $request->input('game_name'),
  
     
    ];
    
$updatedata->update($data);

if ($updatedata) {
   return response()->json(['status' => true, 'location' => route('show_all_GameResult'), 'message' => 'Data update to the table successfully!']);
} else {
   return response()->json(['status' => false, 'message' => "Error Occurred, Please try again"]);
}
    }
    public  function delete_GameResult(Request $request)
    {
       $delete = GameResult::where('id', $request->id)->delete();
  
       if ($delete) {
           return response()->json(['status' => true, 'message' => "Data Deleted Successfully"]);
       } else {
           return response()->json(['status' => false, 'message' => "Error Occurred, Please try again"]);
       }
    }
}
