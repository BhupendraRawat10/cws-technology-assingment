<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    public function login()
    {
        return view('auth.login');
    }

    public function login_submit(Request $request)
    {
        // return $request->all();
        $rules = [
            'email'   => 'required',
            'password' => 'required|min:6'
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return response()->json(array('result' => false, 'msg' => $validator->errors()->first()));
        }
     
        $user = User::where('email', $request->email)->first();

        if ($user) {
            if ($user->role_id == 1) {
                if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
                $dashboard = "admin.dashboard";
                return json_encode(['status' => true, 'msg' => "Success, Welcome Back!", 'location' => route($dashboard)]);
            } else {
                return response()->json(array('status' => false, 'msg' => "Invalid User!"));
            }
        }
        elseif ($user->role_id === 2) {
            if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $dashboard = "paiduser.dashboard";
            return json_encode(['status' => true, 'msg' => "Success, Welcome Back!", 'location' => route($dashboard)]);

            }else {
                return response()->json(array('status' => false, 'msg' => "Invalid User!"));
            }
        }
        elseif ($user->role_id === 3) {
            if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            $dashboard = "guest.dashboard";
            return json_encode(['status' => true, 'msg' => "Success, Welcome Back!", 'location' => route($dashboard)]);

            }else {
                return response()->json(array('status' => false, 'msg' => "Invalid User!"));
            }
        }
        else {
            return response()->json(array('status' => false, 'msg' => "Invalid User!"));
        }
        }
 
        return response()->json(array('status' => false, 'msg' => "User Not Found!"));
        exit;
    }
    public function dashboard()
    {
        $game = Game::all();
      return view('admin.dashboard',compact('game'));
    }
    public function paid_dashboard()
    {
      return view('paiduser.dashboard');
    }
    public function guset_dashboard()
    {
      return view('guest.dashboard');
    }

    public function logout()
    { 
        
        Auth::logout();

        return view('auth.login');
    }
}
