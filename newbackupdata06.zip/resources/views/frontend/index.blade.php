@php 
$title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
$description = "Satta king 786 official provides the Satta king game live result 2024 with upcoming free guess Satta number gali satta, disawar satta, ghaziabad satta, faridabad satta, Black satta king 786, 
Satta 786, Delhi satta king, Satta king up, Satta king result, Satta bajar, Satta king chart, Black satta, Satta king 2024, Disawar satta king";
$keywords = "Satta king, Satta king fast, Sattaking, Satta king chart, Faridabad satta king, Satta bajar, Satta number, Satta king 786, Satta king gali disawar, Satta king result, Up satta king, Gali satta, 
Satta king live result, Ghaziabad satta king, Satta result, Satta king disawar, Satta 786"
@endphp

@include('frontend.include.header')

@php
    
$current_year = date('Y');
$current_year_month = date('F Y');
@endphp

  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h4 class="Satta_king_content">
        Satta King 786

      </h4>

    </div>
  </section>
  
<!-- satta king 786 content text -->
<div class="contact-satta">
      <p class="contact-heading">Gali Disawar Leak Jodi Chart</p>
      <p class="contact-text">09xxxxxx42</p>
      <p class="contact-text"> Raazdeep Tiwary</p>
      <div class="btn_section">
        <div class="phone_button">
          <button type="button" class="call-button">

            Call Now</button>
        </div>

        <div class="phone_button">
          <button type="button" class="whatsapp-button">
            WhatsApp Msg</button>
        </div>
      </div>
    </div> 


 
<!-- marquee section -->

  <div class="text_slide">
      <div class="text-center mt-2">
     <h1  style="font-size:2.5rem">Fast Satta King 786 Results: Black Online Satta King 2024</h1>
    <p class="text-custom">
  सट्टा किंग मटका गेम्स के लिए भारत की पहली और एकमात्र Official वेबसाइट satta-king-786.org में सभी सट्टा किंग लवर्स का स्वागत है! Here, you'll find every update with super fast satta live result, Satta king record chart, Satta king 786, Gali satta, Satta king online, Satta king up, Disawar satta, Satta number, Black satta king, Satta king company, Up game king, Satta king live result, Satta king news, Satta bazar, Gali result और बहुत कुछ। हम अपने सट्टा किंग प्लेयर्स की जरुरतों को ध्यान में रखते हुए उनको ज्यादा से ज्यादा Profit कराने के लिए सट्टा लीक जोड़ी और आने वाले सट्टा नंबर की Winning के लिए अपने अनुभव और पुराने सट्टा रिकॉर्ड चार्ट की मदद से सट्टा ट्रिक्स व टिप्स भी प्रदान करते हैं।
    </p>
      <h2 class="text-custom-data">
        Get exclusive Satta King Online Results and Satta King 786 Charts for {{$current_year_month}}, featuring Gali satta, Delhi satta, Faridabad satta, Disawar satta, Black satta, Ghaziabad satta, Satta king up, Black satta king 786, Delhi disawar, and Up satta king, directly from the prestigious Satta King Company.
    </h2>     
    <div>

        <p class="text-size">
           खेलो सट्टा किंग 786, और बनो लाखों का सिकंदर! अब आपके लिए एक शानदार अवसर है - खेलें सट्टा किंग 786 और जीतें हर बार। हम आपके साथ हैं, आपके हर कदम पर साथ देते हुए, और धोखाधड़ी से बचने में मदद करते हुए। तो आज ही सट्टा ऑफिस में आपका रजिस्ट्रेशन कराएं और प्रॉफिट की राह पर अग्रसर हों!
        </p>
    </div>
    <div class="text-padding">
        <div class="text-back" style="background-color: #ffc107">
            <a style="text-decoration:none; display: block;" href="{{ route('admin.showalldata') }}">
                <p class="text-link" style="font-size: 20px; margin: 0;">
                  Click on the link to view 786 Satta Record Charts of {{$current_year}} for Gali Satta King, Disawar Satta King, Ghaziabad Satta, Black Satta King, Delhi Satta King, and Faridabad Satta are available here.
                </p>
            </a>
        </div>
    </div>
    
</div>
  </div>
  <div class="text_slide">
    <marquee>
      <h3 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
      Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
      Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king 2024, 786 satta king, Satta king game</h3>
    </marquee>
  </div>

 
 
  

  <!-- Admin Game Start -->
  <section>
    <div class="datetime_section">
      <div id="datetime" class="datetime_box">

      </div>
    </div>

    <div class="text_section">

  @include('frontend.gamecode.gamename')

    </div>

  </section>
  
  <!-- Admin Game End -->
  
  


  <!-- result section -->
  <section>

   <div class="result_box">
    @include('frontend.gamecode.result')

    
    </div>
  </section>

 <!-- result section end -->


 
 @php
 $currentMonth = request()->has('month') ? request('month') : now()->format('F Y');
 $currentCarbon = \Carbon\Carbon::parse($currentMonth);
 $currentYear = $currentCarbon->year;
 
 $groupedData = collect($uniqueDates)->groupBy(function ($date) {
     return \Carbon\Carbon::parse($date)->format('F Y');
 });
 @endphp
 
 <table id="customers">
     <tr id="newformate">
         <th>Date</th>
         @foreach($uniqueGamesval as $gameId => $result)
             <th>{{ $result }}</th>
         @endforeach
     </tr>
     <tbody>
        <h6 style="color:white;text-align:center">{{$currentMonth}}  Satta King Record Chart for Gali, Desawar, Ghaziabad And Faridabad Satta</h6>
         @if($groupedData->has($currentMonth))
             @foreach($groupedData as $month => $dates)
                 @php
                     $firstDate = \Carbon\Carbon::parse($dates->first());
                     $year = $firstDate->year;
                 @endphp
 
                 @if($month === $currentMonth && $year == $currentYear)
                     @foreach($dates as $date)
                         @php
                             $dateCarbon = \Carbon\Carbon::parse($date);
                             $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                 ->where('date', $date)
                                 ->get()
                                 ->keyBy('game_fk_id');
                         @endphp
                         <tr>
                             <td class="mydate">{{ $dateCarbon->format('d-M-y') }}</td>
                             @foreach($uniqueGamesval as $gameId => $gameName)
                                 @php 
                                     $result = $results->get($gameId);
                                 @endphp
                                 <td class="">
                                     @if($result)
                                         {{ $result->result }}
                                     @else
                                         -
                                     @endif
                                 </td>
                             @endforeach
                         </tr>
                     @endforeach
                 @endif
             @endforeach
         @else
             <tr>
                 <td colspan="{{ count($uniqueGamesval) + 1 }}" style="text-align: center;">No data available for {{ $currentMonth }}</td>
             </tr>
         @endif
     </tbody>
 </table>
 
 @php
 $prevMonthName = $currentCarbon->copy()->subMonth()->format('F');
 $nextMonthName = $currentCarbon->copy()->addMonth()->format('F');
 @endphp
 
 <div style="display: flex; justify-content: space-between;">
     <button class="btn btn-primary" style="width: 200px; margin: 12px; border-radius: 10px;">
         <a href="?month={{ $currentCarbon->copy()->subMonth()->format('F Y') }}" style="text-decoration: none; color:black; display: block; width: 100%; height: 100%;"> {{ $prevMonthName }}</a>
     </button>
     <button class="btn btn-primary" style="width: 200px; margin: 12px; border-radius: 10px;" >
         <a href="?month={{ $currentCarbon->copy()->addMonth()->format('F Y') }}" style="text-decoration: none; color:black; display: block; width: 100%; height: 100%;"> {{ $nextMonthName }}</a>
     </button>
 </div>
     

  <!-- record chart -->

  <section>

  
  
    @if(count($gameresultsdata) > 0)
      @php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      @endphp

      @foreach($sortedYears as $year)
          @if($loop->iteration >= count($sortedYears) - 2)
              @php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              @endphp

              @if($uniqueGames->isNotEmpty())

                  @if($loop->first)
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  @endif

                  @foreach($uniqueGames as $result)
                      <?php
                      $currentDate = new DateTime($result['date']);
                      $gameId = $result['game']['id'] ?? null;
                      ?>

                      @if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74]))
                 
                      <div class="newchart text-black">
                              <p class="newchart_content"> <a style="text-decoration: none; color: black;" href="{{route('new_page_year',['year'=> $year])}}">SATTA KING RECORD CHART  {{ $year }}</a></p>
                          </div>
                      @endif

                      {{-- @if(in_array($gameId, [2, 64, 68, 74]))
                      
                      <div class="newchart text-black">
                        <p class="newchart_content">
                            <a style="text-decoration: none; color: black;" href="{{ route('new_page', ['year' => $year, 'name' => $result['game']['name']]) }}">
                                {{ $result['game']['name'] }} Satta King Chart {{ $currentDate ? $currentDate->format('Y') : '' }} 
                            </a>
                            <br>
                        </p>
                    </div>
                      @endif --}}
                      @php
                          $previousYear = $currentDate->format('Y');
                      @endphp
                  @endforeach
              @endif
          @endif
      @endforeach
  @else
      <p class="text-black">No game results available for the current year.</p>
  @endif




  </section>


    @include('frontend.include.footer')

