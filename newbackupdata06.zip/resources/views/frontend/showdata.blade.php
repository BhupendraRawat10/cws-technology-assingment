
@include('frontend.include.header')
<link rel="stylesheet" href="{{ asset('public/css/newstyle.css') }}">
<style>
    /* Media query for even smaller screens */
@media only screen and (max-width: 480px) {
 
 .footer_section {
     width: 50%;
     display: flex;
     justify-content: center;
     gap: 5px;
     flex-wrap: wrap;
 }
 }
</style>
<section>

    <div class="Satta_king">
        <h1 class="Satta_king_content">
            {{ $gamename }} SATTA KING RECORD CHART {{ $gameyear }}

        </h1>

    </div>
</section>

<!-- Satta King Section -->
<div style=" overflow: auto;">
<table id="customers">
    <tr id="newformate">
        <th> Date </th>
        @for ($month = 1; $month <= 12; $month++)
            <th scope="col" class="px-6 py-3 border border-black text-center">
                {{ \Carbon\Carbon::create($gameyear, $month, 1)->format('M') }}
            </th>
        @endfor
    </tr>

    <tbody>
        @for ($day = 1; $day <= 31; $day++)
            <tr id="newformate">
                <th>{{ $day }}</th>
                @for ($innerMonth = 1; $innerMonth <= 12; $innerMonth++)
                    @php
                        $result = null;
                        $daysInMonth = \Carbon\Carbon::create($gameyear, $innerMonth, 1)->daysInMonth;
                        if ($day <= $daysInMonth) {
                            $formattedDate = \Carbon\Carbon::create($gameyear, $innerMonth, $day)->format('Y-m-d');
                            foreach ($dataes as $item) {
                                $result = $item->gameResults->firstWhere('date', $formattedDate);
                                if ($result) {
                                    break;
                                }
                            }
                        }
                    @endphp

                    <td class="">
                        {{ $result ? $result->result : '-' }}
                    </td>
                @endfor
            </tr>
        @endfor
    </tbody>
</table>
</div>

<section>
    @if(count($gameresultsdata) > 0)
        @php
            $sortedYears = collect($gameresultsdata)->keys()->sort();
        @endphp

        @foreach($sortedYears as $year)
            @if($loop->iteration >= count($sortedYears) - 2)
                @php
                    $results = $gameresultsdata[$year];
                    $uniqueGames = collect($results)->unique('game.name');
                    $previousYear = null;
                @endphp

                @if($uniqueGames->isNotEmpty())

                    @if($loop->first)
                        <div class="new-div-class">
                            <p>Additional Text for the first year</p>
                        </div>
                    @endif

                    @foreach($uniqueGames as $result)
                        <?php
                        $currentDate = new DateTime($result['date']);
                        $gameId = $result['game']['id'] ?? null;
                        ?>

                        @php
                            $previousYear = $currentDate->format('Y');
                        @endphp

                        @if(in_array($gameId, [2, 64, 68, 74]) && $result['game']['name'] === $name)
                            <div class="newchart text-black">
                                <p class="newchart_content">
                                    <a style="text-decoration: none; color: black;" href="{{ route('new_page', ['year' => $year, 'name' => $result['game']['name']]) }}">
                                        {{ $result['game']['name'] }} Satta King Chart {{ $currentDate ? $currentDate->format('Y') : '' }}
                                    </a>
                                    <br>
                                </p>
                            </div>
                        @endif

                    @endforeach
                @endif
            @endif
        @endforeach
    @else
        <p class="text-black">No game results available for the current year.</p>
    @endif
</section>




</body>
@include('frontend.include.footer')
