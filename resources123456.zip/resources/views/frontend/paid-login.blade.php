
<title>Delhi satta king game | Up satta king | Satta king gali disawar number | Satta black jodi </title>
<meta name="description" content="Satta king, Satta king delhi, Satta chart, Satta king online, Satta result, Satta king disawar, Gali satta, Satta king ghaziabad, Disawar satta, Satta king chart, Satta number " />
<meta name="keywords" content="Satta king, Satta king online, Satta chart, Satta king ghaziabad, Disawar satta, Satta king chart, Satta king gali disawar, Ghaziabad satta king, Satta king result " />
@include('frontend.include.header')


  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
        Paid Login

      </h1>

    </div>
  </section>


  <!-- form section -->

<section>
    <div class="login-form">
        <p class="login-text">Customer Login Yaha Kare</p>
    

    
<form>
    <div class="grid-container">
    <div class="form-section">
        <div class="input_field">
            <label class="label-name">Username:</label>
            <input type="text"  name="fname" class="field" placeholder="Enter Username">
        </div>
    </div>
    <div class="form-section">
        <div class="input_field">
            <label  class="label-name">Password</label>
            <input type="text" name="fname" class="field" placeholder="Password">
        </div>
    </div>
    <div class="checkbox">
    
            <input type="checkbox" checked="checked">New Member Register Here | Guessing Forum
            <span class="checkmark"></span>
         
    </div>
   
      <div class="form-login">
        <button type="button" class="login-button">Login</button>
      </div>
     
    </div>
  </form>
</div>
</section>






    @include('frontend.include.footer')