<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\GameResult;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class FrontendController extends Controller
{
    public function index_login()
    {
        
   $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
  $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
  $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
  $uniqueDates = GameResult::orderBy('date')->distinct('date')->pluck('date');


    $uniqueGamesval = GameResult::join('games', 'games.id', '=', 'game_results.game_fk_id')

    ->whereIn('game_results.game_fk_id', [2, 64, 68, 74])
    ->distinct('game_results.game_fk_id')
    ->pluck('games.name', 'game_results.game_fk_id');

    $gameresultsdata = GameResult::with('game')
    ->orderByRaw("STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s') DESC")
    ->get()
    ->groupBy(function ($result) {
        return \Carbon\Carbon::parse($result->date)->format('Y');
    });
  
    
    
    return view("frontend.index",compact('gameresultsdata','uniqueGamesval','uniqueDates','title','description','keywords'));
        } 

    public function new_page($year,$name)
    {
       
        $gamename=$name;
        $gameyear=$year;
           $dataes = Game::with(['gameResults' => function ($query) use ($gameyear) {
               $query->whereYear('date', '=', $gameyear);
           }])
           ->where('name', $name)
           ->get();
       

        $title="SATTA KING RECORD CHART";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        
        
   return view("frontend.showdata",compact('dataes','gamename','gameyear','title','description','keywords')); 


    }

    public function game_login()
    {
        $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.login",compact('title','description','keywords'));
    }
    public function game_register()
    {
        $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.register",compact('title','description','keywords'));
    }
    
    public function about_us()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.aboutus",compact('title','description','keywords'));
    }
      public function paid_login()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.paid-login",compact('title','description','keywords'));
    }
      public function contact_us()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.contactus",compact('title','description','keywords'));
    }
         public function disclaimer()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.disclaimer",compact('title','description','keywords'));
    }
          public function privacy_policy()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.privacy_policy",compact('title','description','keywords'));
    }
          public function ghaziabad_satta_king()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.ghaziabad-satta-king",compact('title','description','keywords'));
    }
          public function sattakingchart2020()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.satta-king-chart-2020",compact('title','description','keywords'));
    }
          public function sattakingchart2021()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.satta-king-chart-2021",compact('title','description','keywords'));
    }
          public function sattakingchart2022()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.satta-king-chart-2022",compact('title','description','keywords'));
    }
            public function sattakinggamerecordchart()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
        $uniqueGamesval = GameResult::join('games', 'games.id', '=', 'game_results.game_fk_id')
          // ->orderBy('date', 'asc')
          ->whereIn('game_results.game_fk_id', [2, 64, 68, 74])
          ->distinct('game_results.game_fk_id')
          ->pluck('games.name', 'game_results.game_fk_id');
      
          $gameresultsdata = GameResult::with('game')
          ->orderByRaw("STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s') DESC")
          ->get()
          ->groupBy(function ($result) {
              return \Carbon\Carbon::parse($result->date)->format('Y');
          });
          $uniqueDates = GameResult::orderBy('date')->distinct('date')->pluck('date');
          
          return view("frontend.satta-king-game-record-chart",compact('gameresultsdata','uniqueGamesval','uniqueDates','title','description','keywords'));
        // return view("frontend.satta-king-game-record-chart",compact('title','description','keywords'));
    }
               public function sattakingonlinesattakinggalidisawarnumber()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.satta-king-online-sattaking-gali-disawar-number",compact('title','description','keywords'));
    }
    
                   public function sattarecordchart2021()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.satta-record-chart2021",compact('title','description','keywords'));
    }
                      public function sattarecordchart2022()
    {
         $title="Sattaking | Satta king 786 | Black satta | Satta king online | Ghaziabad satta bajar";
        $description="Satta king, Satta king 786, Satta bajar, Satta king online, Black satta, Satta king chart, Satta 786, Black satta king, Satta number, Gali satta, Black satta king 786, Ghaziabad satta, Satta king online result, Disawar satta king, Ghaziabad satta king, Satta chart, Black satta 786";
        $keywords="Satta king, Satta 786, Satta king online, Black satta king, Satta king 786, Satta result, Satta king ghaziabad, Black satta, Satta king gali disawar, Satta king result, Satta number, Black satta king 786, Satta king game, Satta king disawar, Satta bajar, Satta king online result, Satta king chart " ;
      
        return view("frontend.satta-record-chart2022",compact('title','description','keywords'));
    }
    
    
    public function showalldata()
    {
        $title="Satta Record Chart 2024 for Gali, Disawar, Faridabad and Ghaziabad";
        $description="Official Satta Record Charts of 2024 all months for Gali, Disawar, Faridabad and Ghaziabad";
        $keywords="Satta King Record Chart 2024, Satta Record Chart 2024, Satta King 786 Record Chart 2024, Satta Record Chart 2024, Satta Result 2024, 2024 Satta King " ;
        $uniqueDates = GameResult::orderBy('date')->distinct('date')->pluck('date');
      
      
          $uniqueGamesval = GameResult::join('games', 'games.id', '=', 'game_results.game_fk_id')
          // ->orderBy('date', 'asc')
          ->whereIn('game_results.game_fk_id', [2, 64, 68, 74])
          ->distinct('game_results.game_fk_id')
          ->pluck('games.name', 'game_results.game_fk_id');
      
          $gameresultsdata = GameResult::with('game')
          ->orderByRaw("STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s') DESC")
          ->get()
          ->groupBy(function ($result) {
              return \Carbon\Carbon::parse($result->date)->format('Y');
          });
          // return "hello";
          
          return view("frontend.gamedata.index",compact('gameresultsdata','uniqueGamesval','uniqueDates','title','description','keywords'));
    }
    
    
    public function new_page_year($year)
    {
        $gamename='';
        $gameyear=$year;
        $dataes = Game::with(['gameResults' => function ($query) use ($gameyear) {
            $query->whereYear('date', '=', $gameyear);
        }])
        ->whereIn('id', [2, 64, 68, 74])
        ->get();
        
        //    return $dataes;
        $title="Satta Record Chart $gameyear for Gali, Disawar, Faridabad and Ghaziabad";
        $description="Official Satta Record Charts of $gameyear all months for Gali, Disawar, Faridabad and Ghaziabad";
        $keywords="Satta King Record Chart $gameyear, Satta Record Chart $gameyear, Satta King 786 Record Chart $gameyear, Satta Record Chart $gameyear, Satta Result $gameyear, $gameyear Satta King " ;
        $currentYear = $year;
        $uniqueDates = GameResult::select('date')
            ->whereYear('date', $currentYear)
            ->distinct()
            ->pluck('date');
      
        $uniqueGamesval =GameResult::join('games', 'games.id', '=', 'game_results.game_fk_id')
            ->select('games.name', 'game_results.game_fk_id')
            ->whereYear('game_results.date', $currentYear)
            ->whereIn('game_results.game_fk_id', [2, 64, 68, 74])
            ->distinct('game_results.game_fk_id')
            ->pluck('games.name', 'game_results.game_fk_id');
      
        $groupedData = collect($uniqueDates)->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date)->format('F Y');
        });
        $gameresultsdata = GameResult::with('game')
        ->orderByRaw("STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s') DESC")
        ->get()
        ->groupBy(function ($result) {
            return \Carbon\Carbon::parse($result->date)->format('Y');
        });
    
    return view("frontend.gamedata.yearwisedata",compact('gameresultsdata','gameyear','uniqueGamesval','groupedData','currentYear','uniqueDates','title','description','keywords'));

    }
    
      public function game_record($name)
      {

        $gameyear = now()->format('Y');
           $dataes = Game::with('gameResults')
           ->where('id', $name)
           ->get();
           $dataesse = Game::with('gameResults')
           ->where('id', $name)
           ->first();
        $gamename= $dataesse->name;
        $uniqueDates = GameResult::orderBy('date')->distinct('date')->pluck('date');
   $gameIdvalue= $name;

        $uniqueGamesval = GameResult::join('games', 'games.id', '=', 'game_results.game_fk_id')
        // ->orderBy('date', 'asc')
        ->whereIn('game_results.game_fk_id', [2, 64, 68, 74])
        ->distinct('game_results.game_fk_id')
        ->pluck('games.name', 'game_results.game_fk_id');
    
        $gameresultsdata = GameResult::with('game')
        ->orderByRaw("STR_TO_DATE(date, '%Y-%m-%d %H:%i:%s') DESC")
        ->get()
        ->groupBy(function ($result) {
            return \Carbon\Carbon::parse($result->date)->format('Y');
        });

        $title="$gamename Satta 2024 Result and $gamename Satta King Record Chart of $gameyear year";
        $description="View the accurate and verified $gamename Satta Record Chart for the year of $gameyear direct from official website of $gamename Satta $gameyear";
        $keywords="$gamename Satta, $gamename Satta King, $gamename Record Chart, $gamename Result, $gamename Fast Result, $gamename Live, $gamename Company" ;
      
        
   return view("frontend.gamedata.gamealldata",compact('dataes','gameIdvalue','gamename','gameyear','title','description','keywords','uniqueDates','uniqueGamesval','gameresultsdata')); 
//    return view("frontend.showdata",compact('dataes','gamename','gameyear','title','description','keywords')); 
      }
    
}
