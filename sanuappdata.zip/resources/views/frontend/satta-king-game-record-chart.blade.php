<title>Satta bazar | Satta king chart | Gali satta | Satta king disawar | Satta record chart </title>
<meta name="description" content="Satta chart, Satta king delhi, Black satta, Satta king chart, Gali satta, Satta king online, Disawar satta, Ghaziabad satta, Satta king, Satta bajar, Disawar satta chart, Satta record satta, Gali satta king " />
<meta name="keywords" content="Satta king chart, Delhi satta, Satta record chart, Satta number, Satta king gali disawar, Satta bazar, Gali satta, Disawar satta, Ghaziabad satta, Gali disawar chart " />
@include('frontend.include.header')
<link rel="stylesheet" href="{{ asset('public/css/newstyle.css') }}">
@php
    
$current_year = date('Y');
@endphp
  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
    Satta King Chart
      </h1>

    </div>
  </section>
  <div class="text_slide"  >
    <marquee>
      <h5 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
      Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
      Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king 2024, 786 satta king, Satta king game</h5>
    </marquee>
  </div>
    <div class="text_slide">
  
        <div class="text-center mt-2">
       <h2  style="font-size:2.5rem">   
        Satta Record Chart for {{$current_year}} of Gali, Disawar, Faridabad and Ghaziabad Satta
       </h2>
      <p class="text-custom" style="color:blue">satta-king-786.org is the official website for showing Satta Record Charts for 2024 verified from satta company office, here you can find the record charts for Gali Satta record chart 2024, Disawar Satta record chart 2024, Faridabad Satta record chart 2024 and Ghaziabad Satta record chart 2024</p>
        <h4 class="text-custom-data">
            Official Satta Record Chart for {{$current_year}} of Gali and Satta King 786 Charts of {{$current_year}} for Disawar, Faridabad, Ghaziabad and Gali Direct from Company Office  
      </h4>     

  
  </div>
    </div>





    @php
        $currentYear = now()->year;
        $groupedData = collect($uniqueDates)->groupBy(function ($date) {
            return \Carbon\Carbon::parse($date)->format('F Y');
        });

        $currentMonth = null;
    @endphp

    @foreach($groupedData as $month => $dates)
        @php
            $firstDate = \Carbon\Carbon::parse($dates->first());
            $year = $firstDate->year;
        @endphp

        @if($year == $currentYear)
       

     
            <table id="customers">
              
                    <tr id="newformate">
                        <th >
                            Date
                        </th>
                        @foreach($uniqueGamesval as $gameId => $result)
                            <th >
                                {{ $result }}
                            </th>
                        @endforeach
                    </tr>
               
                <tbody>
                    @foreach($dates as $date)
                        @php
                            $dateCarbon = \Carbon\Carbon::parse($date);
                        @endphp

                        <tr                     
                    >
                            <td >
                                {{ $dateCarbon->format('d-M-Y') }}
                            </td>

                            @php
                            $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                                ->where('date', $date)
                                ->get()
                                ->keyBy('game_fk_id');
                            @endphp
                        
                        @foreach($uniqueGamesval as $gameId => $gameName)
                            @php 
                                $result = $results->get($gameId);
                            @endphp
                            <td class="">
                                @if($result)
                                    {{ $result->result }}
                                @else
                                    -
                                @endif
                            </td>
                        @endforeach
                        
                            
                        
                        
                        </tr>
                    @endforeach

                    @php
                        $currentMonth = $month;
                    @endphp
                @endif
            @endforeach

            @if(!is_null($currentMonth))
                </tbody>
            </table>
    
        @endif
    {{-- </div> --}}




 <!-- record chart -->
 <section>

  
  
    @if(count($gameresultsdata) > 0)
      @php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      @endphp

      @foreach($sortedYears as $year)
          @if($loop->iteration >= count($sortedYears) - 2)
              @php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              @endphp

              @if($uniqueGames->isNotEmpty())

                  @if($loop->first)
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  @endif

                  @foreach($uniqueGames as $result)
                      <?php
                      $currentDate = new DateTime($result['date']);
                      $gameId = $result['game']['id'] ?? null;
                      ?>

                      @if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74]))
                      <div class="newchart text-black">
                        <p class="newchart_content"> <a style="text-decoration: none; color: black;" href="{{route('new_page_year',['year'=> $year])}}">SATTA KING RECORD CHART  {{ $year }}</a></p>
                    </div>
                      @endif

                      {{-- @if(in_array($gameId, [2, 64, 68, 74]))
                      
                      <div class="newchart text-black">
                        <p class="newchart_content">
                            <a style="text-decoration: none; color: black;" href="{{ route('new_page', ['year' => $year, 'name' => $result['game']['name']]) }}">
                                {{ $result['game']['name'] }} Satta King Chart {{ $currentDate ? $currentDate->format('Y') : '' }} Record Chart {{ $year ?? '' }}
                            </a>
                            <br>
                        </p>
                    </div>
                    
                      @endif --}}

                      @php
                          $previousYear = $currentDate->format('Y');
                      @endphp
                  @endforeach
              @endif
          @endif
      @endforeach
  @else
      <p class="text-black">No game results available for the current year.</p>
  @endif




  </section>




  <!-- form section -->

<section class="bgwhite p4 m4_universal">
    <div>
    <p>
        {{-- Satta king, Black satta king, Satta number, Satta king 786, Black satta, Satta king fast, Satta disawar, Satta king black, Gali satta, Satta king up, Disawar satta, Satta king delhi, Satta result, Delhi satta king, Ghaziabad satta, Black satta king 786, Sattaking, Satta king online, Black satta chart, Satta king matka, Delhi satta, Up game king, Satta king gali disawar, Satta king fast result, Blacksatta king, Satta bajar, Satta king chart, Satta leak number, Disawar satta king, Satta 786 --}}


    </p>
    </div>
</section>






@include('frontend.include.footer')