{{-- <title>Sattaking | Satta king 786 | Satta result | Black satta king online | Satta bajar | Gali disawar satta</title>
<meta name="description" content="Satta king 786 official provides the Satta king game live result 2024 with upcoming free guess Satta number gali satta, disawar satta, ghaziabad satta, faridabad satta, Black satta king 786, 
Satta 786, Delhi satta king, Satta king up, Satta king result, Satta bajar, Satta king chart, Black satta, Satta king 2024, Disawar satta king" />
<meta name="keywords" content="Satta king, Satta king fast, Sattaking, Satta king chart, Faridabad satta king, Satta bajar, Satta number, Satta king 786, Satta king gali disawar, Satta king result, Up satta king, Gali satta, 
Satta king live result, Ghaziabad satta king, Satta result, Satta king disawar, Satta 786" /> --}}
@include('frontend.include.header')
<link rel="stylesheet" href="{{ asset('public/css/newstyle.css') }}">
<style>
    .text-center{
        text-align: center !important;
    }
.text-custom{
    font-size:16px;
    padding: 18px;
}
.text-custom-data{
    font-size:32px;
    padding: 18px;
}
.text-size{
    font-size:15px;
    padding: 18px;
    text-align: center !important;
    color: red;
}
.text-back{
    background-color: yellow;
    padding: 10px;
}
.text-link{
    font-size:12px;
    padding: 18px;
    color:black;
}
.text-padding{
    padding:0 150;
}
</style>
@php
    
$current_year = date('Y');
@endphp

  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <p class="Satta_king_content">
        Satta King 786

      </p>

    </div>
  </section>
  
<!-- satta king 786 content text -->
<div class="contact-satta">
      <p class="contact-heading">Gali Disawar Leak Jodi Chart</p>
      <p class="contact-text">09xxxxxx42</p>
      <p class="contact-text"> Raazdeep Tiwary</p>
      <div class="btn_section">
        <div class="phone_button">
          <button type="button" class="call-button">

            Call Now</button>
        </div>

        <div class="phone_button">
          <button type="button" class="whatsapp-button">
            WhatsApp Msg</button>
        </div>
      </div>
    </div> 


 
<!-- marquee section -->
<div class="text_slide"  >
  <marquee>
    <h5 class="marquee_text">Satta king, Black satta king, Satta number, Satta king 786 online, Black satta, Satta king fast, Satta king up, Satta king online, Satta king ghaziabad, 786 Satta king, 
    Satta king online result, Ghaziabad satta, Black satta king 786, Sattaking, Black satta 786, Satta king gali disawar, Satta bajar, Satta king chart, Satta leak number, Ghaziabad satta king, 
    Satta 786, Disawar satta king, Gali result, Satta king record chart, Satta result, Satta king delhi, Satta king live result, Satta king 2024, 786 satta king, Satta king game</h5>
  </marquee>
</div>
  <div class="text_slide">

      <div class="text-center mt-2">
     <h1  style="font-size:2.5rem">   Official {{$gameyear}} Satta Reults for Satta King 786, Satta King Online, Black satta king and Satta king fast
     </h1>
    <p class="text-custom">सट्टा किंग मटका गेम्स के लिए भारत की पहली और एकमात्र Official वेबसाइट Satta-King-Office.Com में सभी सट्टा किंग लवर्स का स्वागत है यहां आपको मिलेगा सट्टा किंग फील्ड से जुड़ी हर एक Update के साथ Super fast satta live result, Satta king record chart, Satta king 786, Gali satta, Satta king online, Satta king up, Disawar satta, Satta number, Black satta king, Satta king company, Up game king, Satta king live Result, Satta king news, Satta bazar, Gali result and more. हम अपने सट्टा किंग प्लेयर्स की जरुरतों को ध्यान में रखते हुए उनको ज्यादा से ज्यादा Profit कराने के लिए सट्टा लीक जोड़ी और आने वाले सट्टा नंबर की Winning के लिए अपने अनुभव और पुराने सट्टा रिकॉर्ड चार्ट की मदद से सट्टा ट्रिक्स व टिप्स भी प्रदान करते हैं।</p>
      <h4 class="text-custom-data">
        Satta King Online Results and Satta King 786 Charts of {{$gameyear}} for Gali satta, Delhi satta, Faridabad satta, Disawar satta, Black satta, Ghaziabad satta, Satta king up, Black satta king 786, Delhi disawar and Up satta king Direct from Satta King Company    
    </h4>     
    <div>

        <p class="text-size">सट्टा किंग गेम खेलने वाले सभी भाइयों के लिए ऑफर मिल रहा है अब डायरेक्ट सट्टा किंग ऑफिस से डेट फिक्स फाइनल कन्फर्म सिंगल जोड़ी में गेम लेने का और फ्रॉड सट्टा गेसर्स से बचने का क्योंकि कुछ लोग हमारा नाम लेकर सभी सट्टा प्लेयर्स के साथ धोखा कर रहे हैं। इसलिए जल्दी से जल्दी सट्टा ऑफिस में अपना रजिस्ट्रेशन कराएं और हमारे साथ बिजनेस करके प्रॉफिट ही प्रॉफिट कमाएं</p>
    </div>
  
</div>
  </div>

 
 


  <!-- record chart -->

  @php
  $currentMonth = null;
  $isNewTable = true; 
@endphp

@foreach($groupedData as $month => $dates)
    @php
        $firstDate = \Carbon\Carbon::parse($dates->first());
        $year = $firstDate->year;
        $monthName = $firstDate->format('F');
    @endphp

    @if($year == $currentYear)
        @if ($currentMonth != $monthName || $isNewTable)
            @if (!$isNewTable)
                </tbody>
            </table>
            <br> <!-- Add some space between tables -->
            @endif
            <table id="customers">
                <thead>
                    <tr id="newformate">
                        <th>Date</th>
                        @foreach($uniqueGamesval as $gameId => $result)
                            <th>{{ $result }}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
            @php
                $isNewTable = false; // Reset flag after starting a new table
            @endphp
        @endif
        @foreach($dates as $date)
            @php
                $dateCarbon = \Carbon\Carbon::parse($date);
                $results = \App\Models\GameResult::whereIn('game_fk_id', [2, 64, 68, 74])
                    ->where('date', $date)
                    ->get()
                    ->keyBy('game_fk_id');
            @endphp
            <tr>
                <td class="mydate">{{ $dateCarbon->format('d-M-y') }}</td>
                @foreach($uniqueGamesval as $gameId => $gameName)
                    @php 
                        $result = $results->get($gameId);
                    @endphp
                    <td class="">
                        @if($result)
                            {{ $result->result }}
                        @else
                            -
                        @endif
                    </td>
                @endforeach
            </tr>
        @endforeach
        @php
            $currentMonth = $monthName;
        @endphp
    @endif
@endforeach

@if (!$isNewTable)
    </tbody>
</table>
@endif



<section>

  
  
    @if(count($gameresultsdata) > 0)
      @php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      @endphp

      @foreach($sortedYears as $year)
          @if($loop->iteration >= count($sortedYears) - 2)
              @php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              @endphp

              @if($uniqueGames->isNotEmpty())

                  @if($loop->first)
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  @endif

                  @foreach($uniqueGames as $result)
                      <?php
                      $currentDate = new DateTime($result['date']);
                      $gameId = $result['game']['id'] ?? null;
                      ?>

                      @if($currentDate->format('Y') != $previousYear && in_array($gameId, [2, 64, 68, 74]))
                        
                      <div class="newchart text-black">
                        <p class="newchart_content"><a style="text-decoration: none; color: black;" href="{{route('new_page_year',['year'=> $year])}}">SATTA KING RECORD CHART  {{ $year }}</a></p>
                          </div>
                      @endif

                      {{-- @if(in_array($gameId, [2, 64, 68, 74]))
                      
                      <div class="newchart text-black">
                        <p class="newchart_content">
                            <a style="text-decoration: none; color: black;" href="{{ route('new_page', ['year' => $year, 'name' => $result['game']['name']]) }}">
                                {{ $result['game']['name'] }} Satta King Chart {{ $currentDate ? $currentDate->format('Y') : '' }} 
                            </a>
                            <br>
                        </p>
                    </div>
                      @endif --}}
                      @php
                          $previousYear = $currentDate->format('Y');
                      @endphp
                  @endforeach
              @endif
          @endif
      @endforeach
  @else
      <p class="text-black">No game results available for the current year.</p>
  @endif




  </section>

    @include('frontend.include.footer')

