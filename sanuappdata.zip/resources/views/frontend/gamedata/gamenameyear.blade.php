<section>

  
  
    @if(count($gameresultsdata) > 0)
      @php
          $sortedYears = collect($gameresultsdata)->keys()->sort();
      @endphp

      @foreach($sortedYears as $year)
          @if($loop->iteration >= count($sortedYears) - 2)
              @php
                  $results = $gameresultsdata[$year];
                  $uniqueGames = collect($results)->unique('game.name');
                  $previousYear = null;
              @endphp

              @if($uniqueGames->isNotEmpty())

                  @if($loop->first)
                      <div class="new-div-class">
                          <p>Additional Text for the first year</p>
                      </div>
                  @endif

                  @foreach($uniqueGames as $result)
                  <?php
                  $currentDate = new DateTime($result['date']);
                  $gameId = $result['game']['id'] ?? null;
                  ?>

            

                  @if(in_array($gameId, [$gameIdvalue]))
      
                  <div class="newchart text-black">
                    <p class="newchart_content">
                        <a style="text-decoration: none; color: black;" href="{{ route('new_page', ['year' => $year, 'name' => $result['game']['name']]) }}">
                            {{ $result['game']['name'] }} Satta King Chart {{ $currentDate ? $currentDate->format('Y') : '' }} 
                        </a>
                        <br>
                    </p>
                </div>
                  @endif
                  @php
                      $previousYear = $currentDate->format('Y');
                  @endphp
              @endforeach
          @endif
      @endif
  @endforeach
@else
  <p class="text-black">No game results available for the current year.</p>
@endif

</section>