<html>

<head>
    <link rel="stylesheet" href="{{ asset('public/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('public/css/newstyle.css') }}">
    <link href="{{ asset('public/image/786.png') }}" rel="shortcut icon" type="image/icon" />
    <title>{{ $title }}</title>
    <meta content={{$description}}>
    <meta content={{$keywords}}>
</head>
<style>
    .button_format_footer {
    background-color: #ffe87c;
    font-size: 20px;
    border: none;
    color: #ff0000;
    font-weight: 700;
    cursor: pointer;
}
@media only screen and (max-width: 480px) {
 
 .footer_section {
     width: 50%;
     display: flex;
     justify-content: center;
     gap: 5px;
     flex-wrap: wrap;
 }

 }
</style>
<body>
  @include('frontend.include.header')
  <!-- this for header section -->
  {{-- <section>
    <div class="main_section">
      <div class="header_button">

        <a  href="{{route('index_login')}}" class="menu_button">
          <button type="button" class="btn_format">Home</button></a>
        <button type="button" class="menu_button">Leak Jodi</button>
        <button type="button" class="menu_button">Contact</button>
        <button type="button" class="menu_button">Live Chart</button>
      </div>

  </section> --}}

  



  <!-- Satta king box -->
  <section>

    <div class="Satta_king">
      <h1 class="Satta_king_content">
        Satta King

      </h1>

    </div>
  </section>


  <!-- form section -->

<section>
    <div class="login-form">
        <p class="login-text">Customer Login Yaha Kare</p>
    

    
<form>
    <div class="grid-container">
    <div class="form-section">
        <div class="input_field">
            <label class="label-name">Username:</label>
            <input type="text"  name="fname" class="field" placeholder="Enter Username">
        </div>
    </div>
    <div class="form-section">
        <div class="input_field">
            <label  class="label-name">Password</label>
            <input type="text" name="fname" class="field" placeholder="Password">
        </div>
    </div>
    <div class="checkbox">
    
            <input type="checkbox" checked="checked">New Member Register Here | Guessing Forum
            <span class="checkmark"></span>
         
    </div>
   
      <div class="form-login">
        <button type="button" class="login-button">Login</button>
      </div>
     
    </div>
  </form>
</div>
</section>






  <!-- footer section -->

  {{-- @include('frontend.include.footer') --}}
  <style>
    .button_format_footer {
      background-color: #ffe87c;
      font-size: 20px;
      border: none;
      color: #ff0000;
      font-weight: 700;
      cursor: pointer;
  }
  @media only screen and (max-width: 480px) {
   
   .footer_section {
       width: 50%;
       display: flex;
       justify-content: center;
       gap: 5px;
       flex-wrap: wrap;
   }
  
   }
  </style>
  <section>
    <div class="footer-section">
      <div class="footer_section">
  
        <a  href="{{route('index_login')}}" class="footer_button">
          <button type="button" class="button_format_footer">Home</button>
      </a>
          
          <a href="{{route('game_login')}}" class="footer_button">
        <button type="button"  class="button_format_footer">Login</button>
        </a>
        
        <a href="{{url('contact-us')}}" class="footer_button">
        <button type="button" class="button_format_footer">Contact</button>
        </a>
      
        <a href="{{route('game_register')}}" class="footer_button">
        <button type="button" class="button_format_footer">Registration</button>
        </a>
        
      </div>
  
  </section>
  
  <section>
    <div class="contact-part">
      <p class="footer-text"> © All Right Reserved - 2023</p>
  
      <p class="footer-text"> CONTACT (ADMIN)</p>
  
      <p class="footer-text"> 085XXXXXX42</p>
    </div>
  </section>
  
    <!-- footer section -->
  
  
  
  
  
  
  
  
  


</body>

</html>